export interface ParsedVideoSource {
  kind: 'video' | 'iframe' | 'empty';
  src: string;
}

export function parseVideoSource(rawUrl: string): ParsedVideoSource {
  const url = (rawUrl || '').trim();
  if (!url) {
    return { kind: 'empty', src: '' };
  }

  // YouTube watch or short link -> embed URL
  const ytWatchMatch = url.match(
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/shorts\/)([A-Za-z0-9_-]{6,})/
  );
  if (ytWatchMatch?.[1]) {
    return {
      kind: 'iframe',
      src: `https://www.youtube.com/embed/${ytWatchMatch[1]}?autoplay=1&rel=0`,
    };
  }

  // Already a YouTube embed
  if (url.includes('youtube.com/embed/')) {
    return { kind: 'iframe', src: url };
  }

  // Google Drive file -> preview iframe
  const driveMatch = url.match(/drive\.google\.com\/file\/d\/([^/]+)/);
  if (driveMatch?.[1]) {
    return {
      kind: 'iframe',
      src: `https://drive.google.com/file/d/${driveMatch[1]}/preview`,
    };
  }

  // Vimeo -> player iframe
  const vimeoMatch = url.match(/vimeo\.com\/(\d+)/);
  if (vimeoMatch?.[1]) {
    return {
      kind: 'iframe',
      src: `https://player.vimeo.com/video/${vimeoMatch[1]}?autoplay=1`,
    };
  }

  // Direct HTML5 media files
  if (/\.(mp4|webm|ogg|m4v)(\?.*)?$/i.test(url)) {
    return { kind: 'video', src: url };
  }

  // Otherwise assume embeddable player iframe (Streamtape, Doodstream, etc.)
  return { kind: 'iframe', src: url };
}

export function formatNumber(n: number): string {
  return new Intl.NumberFormat('en-US').format(n);
}
