export type MediaType = 'movie' | 'series';

export interface EpisodeItem {
  id: string;
  season: number;
  episodeNumber: number;
  title: string;
  duration: string;
  watchUrl: string;
  downloadUrl: string;
}

export interface MovieItem {
  id: string;
  title: string;
  type: MediaType;
  genre: string;
  translator: string;
  posterUrl: string;
  backdropUrl: string;
  watchUrl: string;
  downloadUrl: string;
  trailerUrl?: string;
  description: string;
  year: number;
  duration: string;
  rating: string;
  isNew: boolean;
  isFeatured: boolean;
  views: number;
  downloads: number;
  episodes?: EpisodeItem[];
  createdAt: string;
}

export interface TranslatorProfile {
  id: string;
  name: string;
  nickname: string;
  specialty: string;
  bio: string;
  accentHex: string;
  avatarUrl?: string;
}

export interface AdsConfig {
  enabled: boolean;
  providerName: string;
  apiEndpointUrl: string;
  apiKey: string;
  vastOrBannerUrl: string;
  adBannerImageUrl: string;
  adBannerTargetUrl: string;
  rpmUsd: number;
  preRollSeconds: number;
  adsenseClientId: string;
  adsenseSlotId: string;
  adsenseAutoAds: boolean;
}

export interface PublicAdsConfig {
  enabled: boolean;
  providerName: string;
  vastOrBannerUrl: string;
  adBannerImageUrl: string;
  adBannerTargetUrl: string;
  preRollSeconds: number;
  adsenseClientId: string;
  adsenseSlotId: string;
  adsenseAutoAds: boolean;
}

export interface CloudflareConfig {
  d1Enabled: boolean;
  accountId: string;
  d1DatabaseId: string;
  apiToken: string;
  r2Enabled: boolean;
  r2BucketName: string;
  r2AccessKeyId: string;
  r2SecretAccessKey: string;
  r2PublicUrl: string;
}

export type ViewEventType = 'watch' | 'download' | 'ad_impression';

export interface ViewLog {
  id: string;
  ipAddress: string;
  userAgent: string;
  movieId: string;
  movieTitle: string;
  eventType: ViewEventType;
  adsApiSynced: boolean;
  adsApiStatus: string;
  timestamp: string;
}

export interface AnalyticsSummary {
  totalViews: number;
  uniqueIps: number;
  totalDownloads: number;
  adImpressions: number;
  estimatedRevenueUsd: number;
  rpmUsd: number;
  recentLogs: ViewLog[];
  topMovies: Array<{
    id: string;
    title: string;
    translator: string;
    type: MediaType;
    views: number;
    downloads: number;
  }>;
  ipBreakdown: Array<{
    ipAddress: string;
    totalEvents: number;
    lastSeen: string;
    lastMovie: string;
  }>;
}

export interface DatabaseSchema {
  movies: MovieItem[];
  translators: TranslatorProfile[];
  adsConfig: AdsConfig;
  cloudflareConfig: CloudflareConfig;
  viewLogs: ViewLog[];
}
