import {
  Clapperboard,
  Download,
  ExternalLink,
  Film,
  Play,
  SkipForward,
  Tv,
  X,
} from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import type { EpisodeItem, MovieItem, PublicAdsConfig } from '../types.ts';
import { formatNumber, parseVideoSource } from '../utils/video.ts';
import { AdSenseSlot } from './AdSenseSlot.tsx';

interface MovieModalProps {
  movie: MovieItem;
  initialPlay: boolean;
  adsConfig: PublicAdsConfig | null;
  relatedMovies: MovieItem[];
  onClose: () => void;
  onSelectMovie: (movie: MovieItem) => void;
  onTrackEvent: (movieId: string, eventType: 'watch' | 'download' | 'ad_impression') => void;
}

export function MovieModal({
  movie,
  initialPlay,
  adsConfig,
  relatedMovies,
  onClose,
  onSelectMovie,
  onTrackEvent,
}: MovieModalProps) {
  const [isPlaying, setIsPlaying] = useState(initialPlay);
  const [isTrailerMode, setIsTrailerMode] = useState(false);
  const [activeEpisode, setActiveEpisode] = useState<EpisodeItem | null>(
    movie.episodes && movie.episodes.length > 0 ? movie.episodes[0] : null
  );
  const [adCountdown, setAdCountdown] = useState(0);
  const [videoError, setVideoError] = useState(false);

  // Reset state when switching movies
  useEffect(() => {
    setIsPlaying(initialPlay);
    setIsTrailerMode(false);
    setVideoError(false);
    const firstEp =
      movie.episodes && movie.episodes.length > 0 ? movie.episodes[0] : null;
    setActiveEpisode(firstEp);

    if (initialPlay) {
      onTrackEvent(movie.id, 'watch');
      if (adsConfig?.enabled && adsConfig.preRollSeconds > 0) {
        setAdCountdown(adsConfig.preRollSeconds);
        onTrackEvent(movie.id, 'ad_impression');
      } else {
        setAdCountdown(0);
      }
    } else {
      setAdCountdown(0);
    }
  }, [movie.id, initialPlay]);

  // Pre-roll countdown timer
  useEffect(() => {
    if (adCountdown <= 0) return;
    const timer = setTimeout(() => {
      setAdCountdown((prev) => Math.max(0, prev - 1));
    }, 1000);
    return () => clearTimeout(timer);
  }, [adCountdown]);

  // Close on Escape
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const currentWatchUrl = isTrailerMode
    ? movie.trailerUrl || ''
    : activeEpisode
      ? activeEpisode.watchUrl
      : movie.watchUrl;

  const currentDownloadUrl = activeEpisode
    ? activeEpisode.downloadUrl
    : movie.downloadUrl;

  const parsedVideo = useMemo(
    () => parseVideoSource(currentWatchUrl),
    [currentWatchUrl]
  );

  const startWatching = (episode?: EpisodeItem) => {
    if (episode) {
      setActiveEpisode(episode);
    }
    setIsTrailerMode(false);
    setVideoError(false);
    setIsPlaying(true);
    onTrackEvent(movie.id, 'watch');
    if (adsConfig?.enabled && adsConfig.preRollSeconds > 0) {
      setAdCountdown(adsConfig.preRollSeconds);
      onTrackEvent(movie.id, 'ad_impression');
    } else {
      setAdCountdown(0);
    }
  };

  const startTrailer = () => {
    if (!movie.trailerUrl) return;
    setIsTrailerMode(true);
    setVideoError(false);
    setAdCountdown(0);
    setIsPlaying(true);
  };

  const handleDownload = (url: string) => {
    if (!url) return;
    onTrackEvent(movie.id, 'download');
    const a = document.createElement('a');
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    a.click();
  };

  const hasParts = Boolean(movie.episodes && movie.episodes.length > 0);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={movie.title}
      className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/85 backdrop-blur-sm p-0 sm:p-6 md:p-10"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl bg-[#181818] sm:rounded-xl overflow-hidden border border-white/10 shadow-2xl my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          aria-label="Funga"
          className="absolute top-4 right-4 z-30 w-9 h-9 rounded-full bg-black/75 hover:bg-[#E50914] text-white flex items-center justify-center transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Top Cinema Stage: Player OR Backdrop */}
        <div className="relative aspect-video w-full bg-black">
          {isPlaying ? (
            adCountdown > 0 && !isTrailerMode ? (
              <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-[#1b0b0d] via-[#141414] to-black">
                <p className="text-xs font-medium text-neutral-400 mb-2">
                  {adsConfig?.providerName || 'Kwamamaza'} · Inkunga ituma ureba ku buntu
                </p>
                {adsConfig?.adBannerImageUrl ? (
                  <a
                    href={adsConfig.adBannerTargetUrl || '#'}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="max-w-md w-full mb-4 block rounded overflow-hidden border border-white/15"
                  >
                    <img
                      src={adsConfig.adBannerImageUrl}
                      alt="Itangazo"
                      referrerPolicy="no-referrer"
                      className="w-full h-36 object-cover"
                    />
                  </a>
                ) : null}
                <h4 className="text-lg sm:text-xl font-bold text-white mb-2">
                  Filime iratangira mu masegonda{' '}
                  <span className="text-[#E50914] tabular-nums">{adCountdown}</span>
                </h4>
                <p className="text-xs text-neutral-400 max-w-md mb-4">
                  {movie.title} — Byasobanuwe na {movie.translator}
                </p>
                {adCountdown <= 2 && (
                  <button
                    type="button"
                    onClick={() => setAdCountdown(0)}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded bg-white text-[#141414] text-xs font-bold hover:bg-neutral-200 cursor-pointer"
                  >
                    <SkipForward className="w-4 h-4" />
                    <span>Simbuka Itangazo</span>
                  </button>
                )}
              </div>
            ) : parsedVideo.kind === 'video' && !videoError ? (
              <video
                key={parsedVideo.src}
                src={parsedVideo.src}
                controls
                autoPlay
                playsInline
                onError={() => setVideoError(true)}
                className="w-full h-full object-contain bg-black"
              />
            ) : parsedVideo.kind === 'iframe' && !videoError ? (
              <iframe
                key={parsedVideo.src}
                src={parsedVideo.src}
                title={movie.title}
                allow="autoplay; fullscreen; picture-in-picture"
                allowFullScreen
                className="w-full h-full border-0"
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-[#141414]">
                <Film className="w-10 h-10 text-[#E50914] mb-3" />
                <p className="text-sm font-semibold text-white mb-1">
                  Link yo kureba ntabwo ibashije gufunguka muri uyu mwanya
                </p>
                <p className="text-xs text-neutral-400 mb-4 max-w-md">
                  Ushobora gukoresha buto yo gupakurura cyangwa gufungura link hanze.
                </p>
                {currentWatchUrl && (
                  <a
                    href={currentWatchUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2 rounded bg-[#E50914] text-white text-xs font-semibold hover:bg-[#c80812]"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>Fungura Video Hanze</span>
                  </a>
                )}
              </div>
            )
          ) : (
            <>
              <img
                src={movie.backdropUrl || movie.posterUrl}
                alt={movie.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#181818] via-black/35 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-6 sm:p-8 flex flex-col gap-3">
                <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-300">
                  <span className="text-[#E50914] font-semibold">
                    {movie.type === 'series' ? 'Seri' : 'Filime'}
                  </span>
                  {hasParts && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="text-white font-semibold">
                        Ibice {movie.episodes?.length}
                      </span>
                    </>
                  )}
                  <span aria-hidden="true">·</span>
                  <span>{movie.genre}</span>
                  <span aria-hidden="true">·</span>
                  <span className="tabular-nums">{movie.year}</span>
                  <span aria-hidden="true">·</span>
                  <span>{movie.duration}</span>
                </div>
                <h2 className="text-2xl sm:text-4xl font-bold text-white tracking-tight">
                  {movie.title}
                </h2>
                <div className="flex flex-wrap items-center gap-3 pt-1">
                  <button
                    type="button"
                    onClick={() => startWatching(activeEpisode || undefined)}
                    className="inline-flex items-center gap-2 px-6 py-2.5 rounded bg-white text-[#141414] hover:bg-neutral-200 font-bold text-sm transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>
                      {activeEpisode
                        ? `Reba ${activeEpisode.title}`
                        : 'Reba Filime'}
                    </span>
                  </button>

                  {movie.trailerUrl && (
                    <button
                      type="button"
                      onClick={startTrailer}
                      className="inline-flex items-center gap-2 px-5 py-2.5 rounded bg-white/15 hover:bg-white/25 text-white backdrop-blur-sm font-semibold text-sm transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <Clapperboard className="w-4 h-4" />
                      <span>Reba Trailer</span>
                    </button>
                  )}

                  {currentDownloadUrl && (
                    <button
                      type="button"
                      onClick={() => handleDownload(currentDownloadUrl)}
                      className="inline-flex items-center gap-2 px-5 py-2.5 rounded bg-[#E50914] hover:bg-[#c80812] text-white font-semibold text-sm transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                      <span>Pakurura (Download)</span>
                    </button>
                  )}
                </div>
              </div>
            </>
          )}
        </div>

        {/* Google AdSense / Sponsor Strip when configured */}
        {adsConfig?.enabled &&
          (adsConfig.adsenseClientId ||
            adsConfig.adBannerImageUrl ||
            adsConfig.vastOrBannerUrl) && (
            <div className="px-6 sm:px-8 py-3 bg-[#111111] border-y border-white/10 space-y-2">
              {adsConfig.adsenseClientId && adsConfig.adsenseSlotId ? (
                <AdSenseSlot adsConfig={adsConfig} />
              ) : (
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <span className="text-xs text-neutral-400">
                    Ubufatanye na {adsConfig.providerName}
                  </span>
                  {adsConfig.adBannerTargetUrl ? (
                    <a
                      href={adsConfig.adBannerTargetUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs font-semibold text-[#E50914] hover:underline inline-flex items-center gap-1"
                    >
                      <span>Fungura Igikorwa cy’Abaterankunga</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  ) : (
                    <span className="text-xs text-neutral-500 truncate max-w-xs">
                      {adsConfig.vastOrBannerUrl}
                    </span>
                  )}
                </div>
              )}
            </div>
          )}

        {/* Details, Parts/Episodes & Trailer Toggle Section */}
        <div className="p-6 sm:p-8 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 space-y-3">
              {isPlaying && (
                <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-white/10">
                  <div>
                    <h2 className="text-xl font-bold text-white">{movie.title}</h2>
                    {isTrailerMode ? (
                      <p className="text-xs text-[#E50914] font-semibold">
                        Uri kureba Trailer
                      </p>
                    ) : activeEpisode ? (
                      <p className="text-xs text-neutral-300 font-medium">
                        {activeEpisode.title}
                      </p>
                    ) : null}
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {isTrailerMode && (
                      <button
                        type="button"
                        onClick={() => startWatching(activeEpisode || undefined)}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded bg-white text-[#141414] hover:bg-neutral-200 text-xs font-bold cursor-pointer"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>Reba Filime Nyayo</span>
                      </button>
                    )}
                    {!isTrailerMode && movie.trailerUrl && (
                      <button
                        type="button"
                        onClick={startTrailer}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded bg-white/10 hover:bg-white/20 text-white text-xs font-semibold cursor-pointer"
                      >
                        <Clapperboard className="w-3.5 h-3.5" />
                        <span>Trailer</span>
                      </button>
                    )}
                    {currentDownloadUrl && (
                      <button
                        type="button"
                        onClick={() => handleDownload(currentDownloadUrl)}
                        className="inline-flex items-center gap-2 px-4 py-2 rounded bg-[#E50914] hover:bg-[#c80812] text-white text-xs font-semibold cursor-pointer"
                      >
                        <Download className="w-4 h-4" />
                        <span>Pakurura</span>
                      </button>
                    )}
                  </div>
                </div>
              )}

              <p className="text-sm sm:text-base text-neutral-200 leading-relaxed">
                {movie.description}
              </p>
            </div>

            <div className="space-y-2 text-xs sm:text-sm text-neutral-300">
              <div>
                <span className="text-neutral-500">Uwayisobanuye: </span>
                <span className="text-white font-semibold">{movie.translator}</span>
              </div>
              <div>
                <span className="text-neutral-500">Ubwoko: </span>
                <span className="text-neutral-200">{movie.genre}</span>
              </div>
              <div>
                <span className="text-neutral-500">Ikigero: </span>
                <span className="text-neutral-200">{movie.rating}</span>
              </div>
              <div className="tabular-nums">
                <span className="text-neutral-500">Yarebwe: </span>
                <span className="text-neutral-200">{formatNumber(movie.views)} views</span>
              </div>
              <div className="tabular-nums">
                <span className="text-neutral-500">Yapakuruwe: </span>
                <span className="text-neutral-200">{formatNumber(movie.downloads)}</span>
              </div>
            </div>
          </div>

          {/* Parts / Episodes List (Works for BOTH Multi-Part Movies & Series!) */}
          {hasParts && movie.episodes && (
            <div className="pt-4 border-t border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Tv className="w-4 h-4 text-[#E50914]" />
                  <span>
                    {movie.type === 'series'
                      ? `Ibice bya Seri (${movie.episodes.length})`
                      : `Ibice bya Filime (${movie.episodes.length})`}
                  </span>
                </h3>
              </div>

              <div className="divide-y divide-white/10 border border-white/10 rounded-lg overflow-hidden bg-[#141414]">
                {movie.episodes.map((ep) => {
                  const selected =
                    activeEpisode?.id === ep.id && isPlaying && !isTrailerMode;
                  return (
                    <div
                      key={ep.id}
                      className={`p-3.5 sm:px-5 flex flex-wrap items-center justify-between gap-3 transition-colors ${
                        selected ? 'bg-white/10' : 'hover:bg-white/5'
                      }`}
                    >
                      <div className="flex items-center gap-4 min-w-0">
                        <span className="font-mono text-sm text-neutral-400 tabular-nums shrink-0">
                          {movie.type === 'series'
                            ? `S${ep.season}·E${ep.episodeNumber}`
                            : `Igice ${ep.episodeNumber}`}
                        </span>
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-white truncate">
                            {ep.title}
                          </p>
                          <p className="text-xs text-neutral-400">{ep.duration}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => startWatching(ep)}
                          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded bg-white text-[#141414] hover:bg-neutral-200 text-xs font-bold cursor-pointer"
                        >
                          <Play className="w-3.5 h-3.5 fill-current" />
                          <span>{selected ? 'Iri Gukina' : 'Reba'}</span>
                        </button>
                        {ep.downloadUrl && (
                          <button
                            type="button"
                            onClick={() => handleDownload(ep.downloadUrl)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded bg-white/10 hover:bg-white/20 text-white text-xs font-medium cursor-pointer"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span>Pakurura</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Related Movies */}
          {relatedMovies.length > 0 && (
            <div className="pt-4 border-t border-white/10 space-y-3">
              <h3 className="text-base font-bold text-white">
                Izindi Filime Zisa N’iyi
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {relatedMovies.slice(0, 4).map((rel) => (
                  <button
                    key={rel.id}
                    type="button"
                    onClick={() => onSelectMovie(rel)}
                    className="group text-left rounded-md overflow-hidden bg-[#141414] border border-white/10 hover:border-white/30 transition-colors cursor-pointer"
                  >
                    <div className="aspect-[16/10] w-full overflow-hidden bg-neutral-900">
                      <img
                        src={rel.backdropUrl || rel.posterUrl}
                        alt={rel.title}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                      />
                    </div>
                    <div className="p-2.5 space-y-0.5">
                      <p className="text-xs font-semibold text-white line-clamp-1">
                        {rel.title}
                      </p>
                      <p className="text-[11px] text-neutral-400 truncate">
                        {rel.translator}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
