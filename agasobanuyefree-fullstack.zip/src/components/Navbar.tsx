import { Film, Home, Mic2, Search, Tv } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';

export type NavSection = 'home' | 'movies' | 'series' | 'new' | 'translators' | 'admin';

interface NavbarProps {
  activeSection: NavSection;
  onNavigate: (section: NavSection) => void;
  onFocusSearch: () => void;
}

const NAV_ITEMS: Array<{
  id: NavSection;
  label: string;
  shortLabel: string;
  Icon?: typeof Home;
  emoji?: string;
}> = [
  { id: 'home', label: 'Ahabanza', shortLabel: 'Ahabanza', Icon: Home },
  { id: 'movies', label: 'Filime', shortLabel: 'Filime', Icon: Film },
  { id: 'series', label: 'Seri', shortLabel: 'Seri', Icon: Tv },
  { id: 'new', label: 'Films Nshya', shortLabel: 'Nshya', emoji: '🆕' },
  { id: 'translators', label: 'Abasobanuzi', shortLabel: 'Abasobanuzi', Icon: Mic2 },
];

export function Navbar({ activeSection, onNavigate, onFocusSearch }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const logoClickCountRef = useRef(0);
  const logoClickTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    return () => {
      if (logoClickTimerRef.current) {
        clearTimeout(logoClickTimerRef.current);
      }
    };
  }, []);

  const handleNav = (section: NavSection) => {
    onNavigate(section);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Hidden Admin Entry: 10x clicks on the AgasobanuyeFree logo
  const handleLogoClick = () => {
    if (logoClickTimerRef.current) {
      clearTimeout(logoClickTimerRef.current);
    }

    logoClickCountRef.current += 1;

    if (logoClickCountRef.current >= 10) {
      logoClickCountRef.current = 0;
      onNavigate('admin');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    logoClickTimerRef.current = setTimeout(() => {
      logoClickCountRef.current = 0;
    }, 3500);

    if (activeSection !== 'home' && activeSection !== 'admin') {
      handleNav('home');
    } else if (activeSection === 'admin' && logoClickCountRef.current === 1) {
      // Allow single click from anywhere else or keep counting cleanly without kicking out mid-sequence
    }
  };

  return (
    <>
      <header
        className={`fixed top-0 inset-x-0 z-40 transition-colors duration-200 ${
          scrolled || activeSection === 'admin'
            ? 'bg-[#141414]/95 backdrop-blur-md border-b border-white/10'
            : 'bg-gradient-to-b from-black/90 via-black/55 to-transparent'
        }`}
      >
        <div className="max-w-[1440px] mx-auto px-4 sm:px-8 h-16 flex items-center justify-between gap-6">
          {/* Zone 1: Clear, distinct AgasobanuyeFree Logo Mark + Wordmark */}
          <button
            type="button"
            onClick={handleLogoClick}
            className="inline-flex items-center gap-2.5 whitespace-nowrap shrink-0 cursor-pointer select-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E50914] rounded active:scale-[0.98] transition-transform"
            aria-label="AgasobanuyeFree"
          >
            <span className="w-8 h-8 rounded-md bg-[#E50914] flex items-center justify-center shrink-0 shadow-sm">
              <Film className="w-4 h-4 text-white" />
            </span>
            <span className="text-xl sm:text-2xl font-extrabold tracking-tight leading-none">
              <span className="text-[#E50914]">Agasobanuye</span>
              <span className="text-white ml-0.5">Free</span>
            </span>
          </button>

          {/* Zone 2: Persistent Desktop Navigation Buttons with Icons (never hidden on any page/dashboard) */}
          <nav
            aria-label="Ibyiciro by'ingenzi"
            className="hidden md:flex items-center gap-2 lg:gap-4 text-sm font-medium"
          >
            {NAV_ITEMS.map(({ id, label, Icon, emoji }) => {
              const isActive = activeSection === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => handleNav(id)}
                  className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-md whitespace-nowrap shrink-0 transition-colors duration-150 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/60 ${
                    isActive
                      ? 'bg-[#E50914] text-white font-semibold'
                      : 'text-neutral-200 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {emoji ? (
                    <span aria-hidden="true" className="text-sm leading-none shrink-0">
                      {emoji}
                    </span>
                  ) : (
                    Icon && <Icon className="w-4 h-4 shrink-0" />
                  )}
                  <span>{label}</span>
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 Primary Viewer Action (Search) — Admin button completely hidden */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={() => {
                if (activeSection === 'admin' || activeSection === 'translators') {
                  onNavigate('home');
                }
                setTimeout(() => onFocusSearch(), 80);
              }}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-semibold rounded-md bg-white/10 hover:bg-white/20 text-white transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/70"
            >
              <Search className="w-4 h-4 shrink-0" />
              <span>Shakisha</span>
            </button>
          </div>
        </div>
      </header>

      {/* Persistent Mobile Navigation Bar with Icons — Always visible on all pages & dashboards */}
      <nav
        aria-label="Menu ya telefoni"
        className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-[#141414]/98 backdrop-blur-md border-t border-white/15 px-1.5 py-1.5 grid grid-cols-5 gap-1"
      >
        {NAV_ITEMS.map(({ id, shortLabel, Icon, emoji }) => {
          const isActive = activeSection === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => handleNav(id)}
              className={`flex flex-col items-center justify-center gap-1 py-1.5 px-1 rounded-md transition-colors cursor-pointer ${
                isActive
                  ? 'bg-[#E50914] text-white font-semibold'
                  : 'text-neutral-300 hover:text-white hover:bg-white/10'
              }`}
            >
              {emoji ? (
                <span aria-hidden="true" className="text-sm leading-none shrink-0">
                  {emoji}
                </span>
              ) : (
                Icon && <Icon className="w-4 h-4 shrink-0" />
              )}
              <span className="text-[10px] leading-none truncate max-w-full">
                {shortLabel}
              </span>
            </button>
          );
        })}
      </nav>
    </>
  );
}
