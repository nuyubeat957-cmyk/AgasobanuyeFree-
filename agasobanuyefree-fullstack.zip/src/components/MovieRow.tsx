import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useRef } from 'react';
import type { MovieItem } from '../types.ts';
import { MovieCard } from './MovieCard.tsx';

interface MovieRowProps {
  title: string;
  subtitle?: string;
  movies: MovieItem[];
  onSelect: (movie: MovieItem) => void;
  onWatch: (movie: MovieItem) => void;
  onViewAll?: () => void;
}

export function MovieRow({
  title,
  subtitle,
  movies,
  onSelect,
  onWatch,
  onViewAll,
}: MovieRowProps) {
  const trackRef = useRef<HTMLDivElement | null>(null);

  if (movies.length === 0) return null;

  const scrollByAmount = (direction: 'left' | 'right') => {
    const el = trackRef.current;
    if (!el) return;
    const distance = Math.max(el.clientWidth * 0.78, 320);
    el.scrollBy({
      left: direction === 'left' ? -distance : distance,
      behavior: 'smooth',
    });
  };

  return (
    <section className="relative group/row py-4 sm:py-6">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-8 mb-3 flex items-baseline justify-between gap-4">
        <div className="flex items-baseline gap-3">
          <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
            {title}
          </h2>
          {subtitle && (
            <span className="hidden sm:inline text-xs text-neutral-400">
              {subtitle}
            </span>
          )}
        </div>
        {onViewAll && (
          <button
            type="button"
            onClick={onViewAll}
            className="text-xs font-semibold text-neutral-300 hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Reba Zose →
          </button>
        )}
      </div>

      <div className="relative max-w-[1440px] mx-auto">
        <button
          type="button"
          aria-label={`Garuka inyuma muri ${title}`}
          onClick={() => scrollByAmount('left')}
          className="hidden sm:flex absolute left-2 top-1/2 -translate-y-1/2 z-20 w-10 h-20 items-center justify-center rounded bg-black/75 text-white opacity-0 group-hover/row:opacity-100 hover:bg-black transition-opacity duration-150 cursor-pointer"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        <div
          ref={trackRef}
          className="flex gap-3 sm:gap-4 overflow-x-auto no-scrollbar px-4 sm:px-8 scroll-smooth"
        >
          {movies.map((movie) => (
            <div
              key={movie.id}
              className="w-[155px] sm:w-[190px] lg:w-[215px] shrink-0"
            >
              <MovieCard movie={movie} onSelect={onSelect} onWatch={onWatch} />
            </div>
          ))}
        </div>

        <button
          type="button"
          aria-label={`Komeza imbere muri ${title}`}
          onClick={() => scrollByAmount('right')}
          className="hidden sm:flex absolute right-2 top-1/2 -translate-y-1/2 z-20 w-10 h-20 items-center justify-center rounded bg-black/75 text-white opacity-0 group-hover/row:opacity-100 hover:bg-black transition-opacity duration-150 cursor-pointer"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>
    </section>
  );
}
