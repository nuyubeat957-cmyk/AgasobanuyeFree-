import { Film, Play } from 'lucide-react';
import { useState } from 'react';
import type { MovieItem } from '../types.ts';
import { formatNumber } from '../utils/video.ts';

interface MovieCardProps {
  movie: MovieItem;
  onSelect: (movie: MovieItem) => void;
  onWatch: (movie: MovieItem) => void;
}

export function MovieCard({ movie, onSelect, onWatch }: MovieCardProps) {
  const [imgError, setImgError] = useState(false);

  return (
    <article className="group relative flex flex-col shrink-0 w-full cursor-pointer">
      {/* Poster Container */}
      <div
        onClick={() => onSelect(movie)}
        className="relative aspect-[3/4] w-full rounded-md overflow-hidden bg-[#1F1F1F] border border-white/10 transition-transform duration-200 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.03] group-hover:border-white/30"
      >
        {!imgError && movie.posterUrl ? (
          <img
            src={movie.posterUrl}
            alt={movie.title}
            loading="lazy"
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-4 text-center bg-gradient-to-br from-[#231416] via-[#181818] to-[#111111]">
            <Film className="w-8 h-8 text-[#E50914] mb-2 opacity-80" />
            <span className="text-xs font-semibold text-neutral-200 line-clamp-2">
              {movie.title}
            </span>
          </div>
        )}

        {/* Measured hover overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/25 to-transparent opacity-80 group-hover:opacity-100 transition-opacity duration-200" />

        {/* Quick Play Overlay Icon on Hover */}
        <button
          type="button"
          aria-label={`Reba ${movie.title}`}
          onClick={(e) => {
            e.stopPropagation();
            onWatch(movie);
          }}
          className="absolute inset-0 m-auto w-12 h-12 rounded-full bg-[#E50914]/95 text-white flex items-center justify-center opacity-0 scale-90 group-hover:opacity-100 group-hover:scale-100 transition-all duration-200 shadow-lg cursor-pointer"
        >
          <Play className="w-5 h-5 fill-current ml-0.5" />
        </button>

        {/* Bottom text inside scrim */}
        <div className="absolute inset-x-0 bottom-0 p-3 space-y-1">
          <div className="flex items-center gap-1.5 text-[11px] font-medium text-neutral-300">
            {movie.isNew && (
              <>
                <span className="text-[#E50914] font-semibold">Nshya</span>
                <span aria-hidden="true">·</span>
              </>
            )}
            <span>{movie.type === 'series' ? 'Seri' : 'Filime'}</span>
            {movie.episodes && movie.episodes.length > 0 && (
              <>
                <span aria-hidden="true">·</span>
                <span>Ibice {movie.episodes.length}</span>
              </>
            )}
            <span aria-hidden="true">·</span>
            <span>{movie.genre}</span>
          </div>
          <h3 className="text-sm font-bold text-white leading-snug line-clamp-1">
            {movie.title}
          </h3>
          <div className="flex items-center justify-between text-[11px] text-neutral-400">
            <span className="truncate max-w-[68%]">{movie.translator}</span>
            <span className="tabular-nums shrink-0">{formatNumber(movie.views)} views</span>
          </div>
        </div>
      </div>
    </article>
  );
}
