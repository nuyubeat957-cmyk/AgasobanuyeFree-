import { Download, Info, Play } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { MovieItem } from '../types.ts';

interface HeroBillboardProps {
  featuredMovies: MovieItem[];
  onWatch: (movie: MovieItem) => void;
  onOpenDetail: (movie: MovieItem) => void;
}

export function HeroBillboard({
  featuredMovies,
  onWatch,
  onOpenDetail,
}: HeroBillboardProps) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [imgError, setImgError] = useState(false);

  const list = featuredMovies.length > 0 ? featuredMovies : [];

  useEffect(() => {
    if (list.length <= 1) return;
    const timer = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % list.length);
      setImgError(false);
    }, 8000);
    return () => clearInterval(timer);
  }, [list.length]);

  if (list.length === 0) return null;
  const movie = list[activeIndex % list.length];

  return (
    <section className="relative w-full min-h-[72vh] lg:min-h-[82vh] flex items-end pb-14 sm:pb-20 pt-24 overflow-hidden bg-[#141414]">
      {/* Full-bleed Backdrop Image with CSS fallback */}
      <div className="absolute inset-0">
        {!imgError && movie.backdropUrl ? (
          <img
            src={movie.backdropUrl}
            alt={movie.title}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover object-center transition-opacity duration-500"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-neutral-900 via-[#1b0b0c] to-[#141414]" />
        )}
        {/* Measured contrast scrims */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#141414] via-[#141414]/45 to-black/30" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#141414] via-[#141414]/70 to-transparent" />
      </div>

      {/* Hero Foreground Content */}
      <div className="relative z-10 max-w-[1440px] w-full mx-auto px-4 sm:px-8 flex flex-col lg:flex-row lg:items-end justify-between gap-8">
        <div className="max-w-2xl space-y-4">
          {/* Unboxed typographic metadata line (Zero-Pill rule) */}
          <div className="flex flex-wrap items-center gap-2.5 text-xs sm:text-sm font-medium text-neutral-300">
            <span className="text-[#E50914] font-semibold">
              {movie.type === 'series' ? 'Seri Isanzwe' : 'Filime Yatoranyijwe'}
            </span>
            <span aria-hidden="true">·</span>
            <span>{movie.genre}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">{movie.year}</span>
            <span aria-hidden="true">·</span>
            <span>{movie.duration}</span>
            <span aria-hidden="true">·</span>
            <span className="text-white font-semibold">
              Byasobanuwe na {movie.translator}
            </span>
          </div>

          <h1
            className="text-3xl sm:text-5xl lg:text-6xl font-bold text-white tracking-tight leading-[1.08]"
            style={{ textWrap: 'balance' }}
          >
            {movie.title}
          </h1>

          <p className="text-sm sm:text-base text-neutral-200 leading-relaxed max-w-xl line-clamp-3">
            {movie.description}
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              type="button"
              onClick={() => onWatch(movie)}
              className="inline-flex items-center gap-2.5 px-6 py-3 rounded bg-white text-[#141414] hover:bg-neutral-200 font-bold text-sm sm:text-base transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
            >
              <Play className="w-5 h-5 fill-current" />
              <span>Reba Ubu</span>
            </button>

            <button
              type="button"
              onClick={() => onOpenDetail(movie)}
              className="inline-flex items-center gap-2.5 px-6 py-3 rounded bg-white/15 hover:bg-white/25 text-white backdrop-blur-sm font-semibold text-sm sm:text-base transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/70"
            >
              <Info className="w-5 h-5" />
              <span>Ibisobanuro</span>
            </button>

            {movie.downloadUrl && (
              <button
                type="button"
                onClick={() => onOpenDetail(movie)}
                className="inline-flex items-center gap-2 px-5 py-3 rounded border border-white/25 hover:border-white/50 bg-black/35 text-neutral-100 font-medium text-sm sm:text-base transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Pakurura</span>
              </button>
            )}
          </div>
        </div>

        {/* Featured Switcher Controls */}
        {list.length > 1 && (
          <div className="flex items-center gap-2 self-start lg:self-end">
            {list.map((item, idx) => (
              <button
                key={item.id}
                type="button"
                aria-label={`Hitamo ${item.title}`}
                onClick={() => {
                  setActiveIndex(idx);
                  setImgError(false);
                }}
                className={`h-1.5 rounded-full transition-all duration-200 cursor-pointer ${
                  idx === activeIndex % list.length
                    ? 'w-8 bg-[#E50914]'
                    : 'w-3 bg-white/35 hover:bg-white/60'
                }`}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
