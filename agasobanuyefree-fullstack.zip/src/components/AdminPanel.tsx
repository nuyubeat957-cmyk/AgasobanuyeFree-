import {
  CheckCircle2,
  Clapperboard,
  Cloud,
  Database,
  Download,
  Edit3,
  ExternalLink,
  Film,
  Globe,
  HardDrive,
  ImagePlus,
  KeyRound,
  Lock,
  Mic2,
  Plus,
  RefreshCw,
  ShieldCheck,
  Trash2,
  Tv,
  Upload,
  Zap,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import { GENERATED_POSTER_PRESETS, GENRE_OPTIONS } from '../data/seedData.ts';
import type {
  AdsConfig,
  AnalyticsSummary,
  CloudflareConfig,
  EpisodeItem,
  MediaType,
  MovieItem,
  TranslatorProfile,
} from '../types.ts';
import { formatNumber } from '../utils/video.ts';

interface AdminPanelProps {
  movies: MovieItem[];
  translators: TranslatorProfile[];
  onRefreshCatalog: () => Promise<void>;
  onViewWebsite: () => void;
}

type AdminTab = 'movies' | 'translators' | 'ads_analytics' | 'cloudflare';

interface MovieFormState {
  id?: string;
  title: string;
  type: MediaType;
  genre: string;
  translator: string;
  posterUrl: string;
  backdropUrl: string;
  watchUrl: string;
  downloadUrl: string;
  trailerUrl: string;
  description: string;
  year: number;
  duration: string;
  rating: string;
  isNew: boolean;
  isFeatured: boolean;
  episodes: EpisodeItem[];
}

interface TranslatorFormState {
  id?: string;
  name: string;
  nickname: string;
  specialty: string;
  bio: string;
  accentHex: string;
  avatarUrl: string;
}

const EMPTY_MOVIE_FORM: MovieFormState = {
  title: '',
  type: 'movie',
  genre: 'Action',
  translator: 'Rocky Kirabiranya',
  posterUrl: GENERATED_POSTER_PRESETS[0].url,
  backdropUrl: GENERATED_POSTER_PRESETS[0].backdrop,
  watchUrl: '',
  downloadUrl: '',
  trailerUrl: '',
  description: '',
  year: 2026,
  duration: '1h 55m',
  rating: '16+',
  isNew: true,
  isFeatured: false,
  episodes: [],
};

const EMPTY_TRANSLATOR_FORM: TranslatorFormState = {
  name: '',
  nickname: '',
  specialty: 'Action & Drama',
  bio: '',
  accentHex: '#E50914',
  avatarUrl: '',
};

export function AdminPanel({
  movies,
  translators,
  onRefreshCatalog,
  onViewWebsite,
}: AdminPanelProps) {
  const [passcode, setPasscode] = useState<string>(() => {
    try {
      return sessionStorage.getItem('agasobanuye_admin_code') || '';
    } catch {
      return '';
    }
  });
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loginInput, setLoginInput] = useState('');
  const [loginError, setLoginError] = useState('');
  const [activeTab, setActiveTab] = useState<AdminTab>('movies');

  // Movie Form State
  const [form, setForm] = useState<MovieFormState>(EMPTY_MOVIE_FORM);
  const [customTranslator, setCustomTranslator] = useState('');
  const [movieSearch, setMovieSearch] = useState('');
  const [statusMsg, setStatusMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [saving, setSaving] = useState(false);
  const [uploadingField, setUploadingField] = useState<string>('');

  // Translator Form State
  const [trForm, setTrForm] = useState<TranslatorFormState>(EMPTY_TRANSLATOR_FORM);
  const [trStatusMsg, setTrStatusMsg] = useState('');
  const [trErrorMsg, setTrErrorMsg] = useState('');
  const [savingTranslator, setSavingTranslator] = useState(false);

  // Ads Config & Analytics State
  const [adsConfig, setAdsConfig] = useState<AdsConfig>({
    enabled: true,
    providerName: 'Google AdSense / Custom Ads API',
    apiEndpointUrl: '',
    apiKey: '',
    vastOrBannerUrl: '',
    adBannerImageUrl: '',
    adBannerTargetUrl: '',
    rpmUsd: 2.5,
    preRollSeconds: 5,
    adsenseClientId: '',
    adsenseSlotId: '',
    adsenseAutoAds: true,
  });
  const [analytics, setAnalytics] = useState<AnalyticsSummary | null>(null);
  const [adsTestResult, setAdsTestResult] = useState('');
  const [loadingAnalytics, setLoadingAnalytics] = useState(false);

  // Cloudflare D1 & R2 Config State
  const [cfConfig, setCfConfig] = useState<CloudflareConfig>({
    d1Enabled: false,
    accountId: '',
    d1DatabaseId: '',
    apiToken: '',
    r2Enabled: false,
    r2BucketName: '',
    r2AccessKeyId: '',
    r2SecretAccessKey: '',
    r2PublicUrl: '',
  });
  const [cfStatusMsg, setCfStatusMsg] = useState('');
  const [r2QuickUrl, setR2QuickUrl] = useState('');

  // Bulk JSON Import State
  const [showBulkImport, setShowBulkImport] = useState(false);
  const [bulkJsonText, setBulkJsonText] = useState('');
  const [bulkStatusMsg, setBulkStatusMsg] = useState('');
  const [exportingZip, setExportingZip] = useState(false);

  const authHeaders = {
    'Content-Type': 'application/json',
    'x-admin-passcode': passcode,
  };

  useEffect(() => {
    if (!passcode) return;
    fetch('/api/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ passcode }),
    })
      .then((r) => {
        setIsAuthenticated(r.ok);
      })
      .catch(() => setIsAuthenticated(false));
  }, [passcode]);

  const loadAdminData = async () => {
    if (!passcode) return;
    setLoadingAnalytics(true);
    try {
      const [adsRes, anaRes, cfRes] = await Promise.all([
        fetch('/api/admin/ads-config', { headers: { 'x-admin-passcode': passcode } }),
        fetch('/api/admin/analytics', { headers: { 'x-admin-passcode': passcode } }),
        fetch('/api/admin/cloudflare-config', {
          headers: { 'x-admin-passcode': passcode },
        }),
      ]);
      if (adsRes.ok) {
        setAdsConfig(await adsRes.json());
      }
      if (anaRes.ok) {
        setAnalytics(await anaRes.json());
      }
      if (cfRes.ok) {
        setCfConfig(await cfRes.json());
      }
    } finally {
      setLoadingAnalytics(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      loadAdminData();
    }
  }, [isAuthenticated]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    const res = await fetch('/api/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ passcode: loginInput }),
    });
    if (res.ok) {
      try {
        sessionStorage.setItem('agasobanuye_admin_code', loginInput);
      } catch {
        // Ignore storage restrictions
      }
      setPasscode(loginInput);
      setIsAuthenticated(true);
    } else {
      const data = await res.json().catch(() => ({}));
      setLoginError(data.error || 'Ijambo ry’ibanga si ryo.');
    }
  };

  // Real File Upload Handler for Posters, Backdrops, and Translator Photos
  const handleImageFileUpload = async (
    file: File | undefined,
    field: 'poster' | 'backdrop' | 'translatorAvatar'
  ) => {
    if (!file) return;
    setUploadingField(field);
    setErrorMsg('');
    setTrErrorMsg('');
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => reject(new Error('Byanze gusoma ifoto.'));
        reader.readAsDataURL(file);
      });

      const res = await fetch('/api/admin/upload-image', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ filename: file.name, dataUrl }),
      });

      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.url) {
        const msg = data.error || 'Ntibishobotse kohereza ifoto.';
        if (field === 'translatorAvatar') setTrErrorMsg(msg);
        else setErrorMsg(msg);
        return;
      }

      if (field === 'poster') {
        setForm((prev) => ({
          ...prev,
          posterUrl: data.url,
          backdropUrl: prev.backdropUrl || data.url,
        }));
      } else if (field === 'backdrop') {
        setForm((prev) => ({ ...prev, backdropUrl: data.url }));
      } else {
        setTrForm((prev) => ({ ...prev, avatarUrl: data.url }));
      }
    } catch {
      const msg = 'Habaye ikosa mu gukora upload y’ifoto.';
      if (field === 'translatorAvatar') setTrErrorMsg(msg);
      else setErrorMsg(msg);
    } finally {
      setUploadingField('');
    }
  };

  // Upload large .zip, .mp4, or image files directly to Cloudflare R2 (or local fallback)
  const handleMediaFileUpload = async (
    file: File | undefined,
    target: 'downloadUrl' | 'watchUrl' | 'r2Quick'
  ) => {
    if (!file) return;
    setUploadingField(target);
    setErrorMsg('');
    setCfStatusMsg('');
    try {
      const res = await fetch('/api/admin/upload-file', {
        method: 'POST',
        headers: {
          'x-admin-passcode': passcode,
          'x-file-name': file.name,
          'Content-Type': file.type || 'application/octet-stream',
        },
        body: file,
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.url) {
        const msg = data.error || 'Ntibishobotse kohereza dosiye.';
        if (target === 'r2Quick') setCfStatusMsg(msg);
        else setErrorMsg(msg);
        return;
      }

      if (target === 'downloadUrl') {
        setForm((prev) => ({ ...prev, downloadUrl: data.url }));
        setStatusMsg(
          `Dosiye yoherejwe (${data.storage === 'cloudflare-r2' ? 'Cloudflare R2' : 'Seriveri'})!`
        );
      } else if (target === 'watchUrl') {
        setForm((prev) => ({ ...prev, watchUrl: data.url }));
        setStatusMsg(
          `Video yoherejwe (${data.storage === 'cloudflare-r2' ? 'Cloudflare R2' : 'Seriveri'})!`
        );
      } else {
        setR2QuickUrl(data.url);
        setCfStatusMsg(
          `Dosiye yoherejwe neza kuri ${data.storage === 'cloudflare-r2' ? 'Cloudflare R2' : 'Seriveri'}: ${data.url}`
        );
      }
    } catch {
      const msg = 'Habaye ikosa mu kohereza dosiye.';
      if (target === 'r2Quick') setCfStatusMsg(msg);
      else setErrorMsg(msg);
    } finally {
      setUploadingField('');
    }
  };

  const handleBulkImport = async () => {
    setBulkStatusMsg('');
    try {
      const parsed = JSON.parse(bulkJsonText);
      const items = Array.isArray(parsed) ? parsed : [parsed];
      const res = await fetch('/api/admin/movies/bulk-import', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ items }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setBulkStatusMsg(data.error || 'Ntibishobotse kwinjiza amafilime.');
        return;
      }
      setBulkStatusMsg(`Filime ${data.count} zinjijwe icyarimwe ku rubuga!`);
      setBulkJsonText('');
      await onRefreshCatalog();
    } catch {
      setBulkStatusMsg('Reba neza ko JSON yawe yanditse neza.');
    }
  };

  const handleSaveAndTestD1 = async () => {
    setCfStatusMsg('Turimo gusuzuma Cloudflare D1...');
    const res = await fetch('/api/admin/cloudflare-d1-test', {
      method: 'POST',
      headers: authHeaders,
      body: JSON.stringify(cfConfig),
    });
    const data = await res.json().catch(() => ({}));
    setCfStatusMsg(data.message || 'Ikosa mu gusuzuma D1.');
  };

  const handleSyncD1 = async (direction: 'push' | 'pull') => {
    setCfStatusMsg(
      direction === 'push'
        ? 'Turimo kohereza amakuru kuri Cloudflare D1...'
        : 'Turimo gukura amakuru muri Cloudflare D1...'
    );
    await fetch('/api/admin/cloudflare-config', {
      method: 'PUT',
      headers: authHeaders,
      body: JSON.stringify(cfConfig),
    });
    const res = await fetch('/api/admin/cloudflare-d1-sync', {
      method: 'POST',
      headers: authHeaders,
      body: JSON.stringify({ direction }),
    });
    const data = await res.json().catch(() => ({}));
    setCfStatusMsg(data.message || 'Ikosa muri D1 Sync.');
    if (data.ok && direction === 'pull') {
      await onRefreshCatalog();
    }
  };

  const handleSaveAndTestR2 = async () => {
    setCfStatusMsg('Turimo gusuzuma Cloudflare R2 Bucket...');
    const res = await fetch('/api/admin/cloudflare-r2-test', {
      method: 'POST',
      headers: authHeaders,
      body: JSON.stringify(cfConfig),
    });
    const data = await res.json().catch(() => ({}));
    setCfStatusMsg(data.message || 'Ikosa mu gusuzuma R2.');
  };

  const handleSaveMovie = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMsg('');
    setErrorMsg('');
    setSaving(true);

    const finalTranslator =
      form.translator === '__custom__' ? customTranslator.trim() : form.translator;

    if (!form.title.trim() || !finalTranslator) {
      setErrorMsg('Uzuza izina rya filime n’izina ry’uwayisobanuye.');
      setSaving(false);
      return;
    }

    const payload = {
      ...form,
      translator: finalTranslator,
      backdropUrl: form.backdropUrl.trim() || form.posterUrl.trim(),
      trailerUrl: form.trailerUrl.trim(),
    };

    try {
      const url = form.id ? `/api/admin/movies/${form.id}` : '/api/admin/movies';
      const method = form.id ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: authHeaders,
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        setErrorMsg(err.error || 'Hari ikosa ryabaye mu kubika filime.');
      } else {
        setStatusMsg(
          form.id
            ? 'Amakuru ya filime yavuguruwe kandi ahita agaragara ku rubuga!'
            : 'Filime nshya yongerewe kandi ihita igaragara ku rubuga!'
        );
        setForm(EMPTY_MOVIE_FORM);
        setCustomTranslator('');
        await onRefreshCatalog();
      }
    } catch {
      setErrorMsg('Ntibishobotse kuvugana na seriveri.');
    } finally {
      setSaving(false);
    }
  };

  const handleEditMovie = (m: MovieItem) => {
    const knownTranslator = translators.some((t) => t.name === m.translator);
    setForm({
      id: m.id,
      title: m.title,
      type: m.type,
      genre: m.genre,
      translator: knownTranslator ? m.translator : '__custom__',
      posterUrl: m.posterUrl,
      backdropUrl: m.backdropUrl,
      watchUrl: m.watchUrl,
      downloadUrl: m.downloadUrl,
      trailerUrl: m.trailerUrl || '',
      description: m.description,
      year: m.year,
      duration: m.duration,
      rating: m.rating,
      isNew: m.isNew,
      isFeatured: m.isFeatured,
      episodes: m.episodes ? [...m.episodes] : [],
    });
    if (!knownTranslator) {
      setCustomTranslator(m.translator);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDeleteMovie = async (id: string) => {
    const res = await fetch(`/api/admin/movies/${id}`, {
      method: 'DELETE',
      headers: { 'x-admin-passcode': passcode },
    });
    if (res.ok) {
      setStatusMsg('Filime yasibwe kandi yahise ikurwa ku rubuga.');
      await onRefreshCatalog();
    }
  };

  const addTwoPartsPreset = () => {
    setForm((prev) => ({
      ...prev,
      episodes: [
        {
          id: `ep-${Date.now()}-1`,
          season: 1,
          episodeNumber: 1,
          title: 'Igice cya 1 (Part 1)',
          duration: '1h 00m',
          watchUrl: prev.watchUrl,
          downloadUrl: prev.downloadUrl,
        },
        {
          id: `ep-${Date.now()}-2`,
          season: 1,
          episodeNumber: 2,
          title: 'Igice cya 2 (Part 2)',
          duration: '1h 00m',
          watchUrl: '',
          downloadUrl: '',
        },
      ],
    }));
  };

  const addEpisodeRow = () => {
    const nextNum = form.episodes.length + 1;
    setForm((prev) => ({
      ...prev,
      episodes: [
        ...prev.episodes,
        {
          id: `ep-${Date.now()}-${nextNum}`,
          season: 1,
          episodeNumber: nextNum,
          title:
            prev.type === 'movie'
              ? `Igice cya ${nextNum} (Part ${nextNum})`
              : `Igice cya ${nextNum}`,
          duration: '45m',
          watchUrl: nextNum === 1 ? prev.watchUrl : '',
          downloadUrl: nextNum === 1 ? prev.downloadUrl : '',
        },
      ],
    }));
  };

  const updateEpisodeField = (
    index: number,
    field: keyof EpisodeItem,
    value: string | number
  ) => {
    setForm((prev) => {
      const copy = [...prev.episodes];
      copy[index] = { ...copy[index], [field]: value };
      return { ...prev, episodes: copy };
    });
  };

  const removeEpisodeRow = (index: number) => {
    setForm((prev) => ({
      ...prev,
      episodes: prev.episodes.filter((_, i) => i !== index),
    }));
  };

  const handleSaveTranslator = async (e: React.FormEvent) => {
    e.preventDefault();
    setTrStatusMsg('');
    setTrErrorMsg('');
    if (!trForm.name.trim()) {
      setTrErrorMsg('Izina ry’umusobanuzi rirakenewe.');
      return;
    }

    setSavingTranslator(true);
    try {
      const url = trForm.id
        ? `/api/admin/translators/${trForm.id}`
        : '/api/admin/translators';
      const method = trForm.id ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: authHeaders,
        body: JSON.stringify({
          name: trForm.name.trim(),
          nickname: trForm.nickname.trim() || trForm.name.trim(),
          specialty: trForm.specialty.trim() || 'Action & Drama',
          bio: trForm.bio.trim() || 'Umusobanuzi w’amafilime mu Kinyarwanda.',
          accentHex: trForm.accentHex || '#E50914',
          avatarUrl: trForm.avatarUrl.trim(),
        }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        setTrErrorMsg(err.error || 'Byanze kubika umusobanuzi.');
      } else {
        setTrStatusMsg(
          trForm.id
            ? 'Amakuru n’ifoto by’umusobanuzi byavuguruwe neza ku rubuga!'
            : 'Umusobanuzi mushya yongeweho neza ku rubuga!'
        );
        setTrForm(EMPTY_TRANSLATOR_FORM);
        await onRefreshCatalog();
      }
    } finally {
      setSavingTranslator(false);
    }
  };

  const handleEditTranslator = (tr: TranslatorProfile) => {
    setTrStatusMsg('');
    setTrErrorMsg('');
    setTrForm({
      id: tr.id,
      name: tr.name,
      nickname: tr.nickname || tr.name,
      specialty: tr.specialty,
      bio: tr.bio,
      accentHex: tr.accentHex || '#E50914',
      avatarUrl: tr.avatarUrl || '',
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDeleteTranslator = async (id: string) => {
    const res = await fetch(`/api/admin/translators/${id}`, {
      method: 'DELETE',
      headers: { 'x-admin-passcode': passcode },
    });
    if (res.ok) {
      if (trForm.id === id) {
        setTrForm(EMPTY_TRANSLATOR_FORM);
      }
      await onRefreshCatalog();
    }
  };

  const handleSaveAdsConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdsTestResult('');
    const res = await fetch('/api/admin/ads-config', {
      method: 'PUT',
      headers: authHeaders,
      body: JSON.stringify(adsConfig),
    });
    if (res.ok) {
      setAdsConfig(await res.json());
      setAdsTestResult('Igenamiterere rya Ads API ryabitswe kandi ryahujwe n’urubuga!');
      await onRefreshCatalog();
      await loadAdminData();
    }
  };

  const handleTestAdsApi = async () => {
    setAdsTestResult('Turimo kugerageza guhuza...');
    const res = await fetch('/api/admin/ads-test', {
      method: 'POST',
      headers: authHeaders,
      body: JSON.stringify({
        apiEndpointUrl: adsConfig.apiEndpointUrl,
        apiKey: adsConfig.apiKey,
        providerName: adsConfig.providerName,
      }),
    });
    const data = await res.json().catch(() => ({}));
    setAdsTestResult(data.message || 'Ikosa mu kugerageza Ads API.');
  };

  const handleExportCsv = async () => {
    const res = await fetch('/api/admin/export-logs', {
      headers: { 'x-admin-passcode': passcode },
    });
    if (!res.ok) return;
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'agasobanuyefree-ip-views.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportProjectZip = async () => {
    setExportingZip(true);
    setCfStatusMsg('Turimo gutunganya dosiye ya agasobanuyefree-fullstack.zip...');
    try {
      const res = await fetch('/api/admin/export-project-zip', {
        headers: { 'x-admin-passcode': passcode },
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        setCfStatusMsg(err.error || 'Ntibishobotse gukora ZIP.');
        return;
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'agasobanuyefree-fullstack.zip';
      a.click();
      URL.revokeObjectURL(url);
      setCfStatusMsg(
        'agasobanuyefree-fullstack.zip yakuweho neza! Irimo Frontend, Backend (server.ts), n’amafoto yose.'
      );
    } catch {
      setCfStatusMsg('Habayeho ikibazo mu gupakurura ZIP.');
    } finally {
      setExportingZip(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <section className="max-w-md mx-auto px-4 pt-32 pb-28">
        <form
          onSubmit={handleLogin}
          className="p-8 rounded-xl bg-[#1A1A1A] border border-white/10 space-y-5"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#E50914]/15 text-[#E50914] flex items-center justify-center">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Injira muri Admin Panel</h1>
              <p className="text-xs text-neutral-400">
                Gucunga Filime, Abasobanuzi, IP Views & Ads API
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-xs font-medium text-neutral-300">
              Ijambo ry’Ibanga (Admin Passcode)
            </label>
            <input
              type="password"
              value={loginInput}
              onChange={(e) => setLoginInput(e.target.value)}
              placeholder="Shyiramo passcode (urugero: admin2026)"
              className="w-full px-4 py-2.5 rounded bg-[#111111] border border-white/15 text-sm text-white focus:outline-none focus:border-[#E50914]"
              required
            />
            <p className="text-[11px] text-neutral-500">
              Passcode y’ibanze ni <code className="font-mono text-neutral-300">admin2026</code>{' '}
              (ushobora kuyihindura ukoresheje <code className="font-mono">ADMIN_PASSCODE</code>).
            </p>
          </div>

          {loginError && (
            <p className="text-xs text-red-400 font-medium">{loginError}</p>
          )}

          <button
            type="submit"
            className="w-full py-2.5 rounded bg-[#E50914] hover:bg-[#c80812] text-white font-semibold text-sm transition-colors cursor-pointer"
          >
            Fungura Admin Panel
          </button>
        </form>
      </section>
    );
  }

  const filteredMovies = movies.filter(
    (m) =>
      m.title.toLowerCase().includes(movieSearch.toLowerCase()) ||
      m.translator.toLowerCase().includes(movieSearch.toLowerCase()) ||
      m.genre.toLowerCase().includes(movieSearch.toLowerCase())
  );

  return (
    <section className="max-w-[1440px] mx-auto px-4 sm:px-8 pt-24 pb-28 space-y-8">
      {/* Admin Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2 text-xs text-[#E50914] font-semibold">
            <ShieldCheck className="w-4 h-4" />
            <span>AgasobanuyeFree Management Console</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white mt-1">
            Admin Panel — Gucunga Urubuga
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Segmented Admin Tabs */}
          <div className="flex flex-wrap items-center gap-1 p-1 bg-[#1F1F1F] rounded-lg border border-white/10">
            <button
              type="button"
              onClick={() => setActiveTab('movies')}
              className={`px-4 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'movies'
                  ? 'bg-[#E50914] text-white'
                  : 'text-neutral-300 hover:text-white'
              }`}
            >
              Filime n’Amaseri ({movies.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('translators')}
              className={`px-4 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'translators'
                  ? 'bg-[#E50914] text-white'
                  : 'text-neutral-300 hover:text-white'
              }`}
            >
              Abasobanuzi ({translators.length})
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('ads_analytics');
                loadAdminData();
              }}
              className={`px-4 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'ads_analytics'
                  ? 'bg-[#E50914] text-white'
                  : 'text-neutral-300 hover:text-white'
              }`}
            >
              Google Ads & IP Views
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('cloudflare');
                loadAdminData();
              }}
              className={`px-4 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'cloudflare'
                  ? 'bg-[#E50914] text-white'
                  : 'text-neutral-300 hover:text-white'
              }`}
            >
              Cloudflare D1 & R2
            </button>
          </div>

          <button
            type="button"
            onClick={async () => {
              await onRefreshCatalog();
              onViewWebsite();
            }}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-white text-[#141414] hover:bg-neutral-200 text-xs font-bold whitespace-nowrap shrink-0 cursor-pointer"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Reba ku Rubuga</span>
          </button>
        </div>
      </div>

      {/* TAB 1: MOVIES & SERIES */}
      {activeTab === 'movies' && (
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
          {/* Add / Edit Movie Form */}
          <form
            onSubmit={handleSaveMovie}
            className="xl:col-span-5 p-6 rounded-xl bg-[#1A1A1A] border border-white/10 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Film className="w-4 h-4 text-[#E50914]" />
                <span>{form.id ? 'Hindura Filime' : 'Ongeramo Filime Nshya'}</span>
              </h2>
              {form.id && (
                <button
                  type="button"
                  onClick={() => {
                    setForm(EMPTY_MOVIE_FORM);
                    setCustomTranslator('');
                  }}
                  className="text-xs text-neutral-400 hover:text-white cursor-pointer"
                >
                  Hagarika Guhindura
                </button>
              )}
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Izina rya Filime / Seri *
                </label>
                <input
                  type="text"
                  required
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                  placeholder="Urugero: Umujyi Utaryama"
                  className="w-full px-3.5 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white focus:outline-none focus:border-[#E50914]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">
                    Movie cyangwa Series *
                  </label>
                  <select
                    value={form.type}
                    onChange={(e) =>
                      setForm({ ...form, type: e.target.value as MediaType })
                    }
                    className="w-full px-3 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white focus:outline-none focus:border-[#E50914]"
                  >
                    <option value="movie">Filime (Movie)</option>
                    <option value="series">Seri (Series)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">
                    Ubwoko bwa Filime (Genre) *
                  </label>
                  <select
                    value={form.genre}
                    onChange={(e) => setForm({ ...form, genre: e.target.value })}
                    className="w-full px-3 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white focus:outline-none focus:border-[#E50914]"
                  >
                    {GENRE_OPTIONS.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Uwayisobanuye (Umusobanuzi) *
                </label>
                <select
                  value={form.translator}
                  onChange={(e) => setForm({ ...form, translator: e.target.value })}
                  className="w-full px-3 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white focus:outline-none focus:border-[#E50914]"
                >
                  {translators.map((t) => (
                    <option key={t.id} value={t.name}>
                      {t.name}
                    </option>
                  ))}
                  <option value="__custom__">+ Undi Musobanuzi (Andika izina)</option>
                </select>
                {form.translator === '__custom__' && (
                  <input
                    type="text"
                    value={customTranslator}
                    onChange={(e) => setCustomTranslator(e.target.value)}
                    placeholder="Andika izina ry'uwayisobanuye"
                    className="mt-2 w-full px-3.5 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white focus:outline-none focus:border-[#E50914]"
                  />
                )}
              </div>

              {/* Poster Upload + URL + Preset Picker */}
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <label className="block text-xs font-medium text-neutral-300">
                    Ifoto ya Filime (Poster) *
                  </label>
                  <label className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-xs font-semibold text-white cursor-pointer">
                    <ImagePlus className="w-3.5 h-3.5" />
                    <span>
                      {uploadingField === 'poster' ? 'Kohereza...' : 'Upload Ifoto'}
                    </span>
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/webp,image/gif"
                      className="hidden"
                      onChange={(e) => {
                        handleImageFileUpload(e.target.files?.[0], 'poster');
                        e.target.value = '';
                      }}
                    />
                  </label>
                </div>

                <div className="flex items-center gap-3">
                  {form.posterUrl && (
                    <img
                      src={form.posterUrl}
                      alt="Poster preview"
                      referrerPolicy="no-referrer"
                      className="w-10 h-14 rounded object-cover border border-white/15 shrink-0 bg-neutral-900"
                    />
                  )}
                  <input
                    type="text"
                    value={form.posterUrl}
                    onChange={(e) => setForm({ ...form, posterUrl: e.target.value })}
                    placeholder="https://... cyangwa kanda Upload Ifoto"
                    className="flex-1 px-3.5 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white focus:outline-none focus:border-[#E50914]"
                  />
                </div>

                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {GENERATED_POSTER_PRESETS.map((preset) => (
                    <button
                      key={preset.url}
                      type="button"
                      onClick={() =>
                        setForm({
                          ...form,
                          posterUrl: preset.url,
                          backdropUrl: preset.backdrop,
                        })
                      }
                      title={preset.label}
                      className={`w-11 h-14 rounded overflow-hidden border shrink-0 cursor-pointer ${
                        form.posterUrl === preset.url
                          ? 'border-[#E50914] ring-2 ring-[#E50914]/50'
                          : 'border-white/15 opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img
                        src={preset.url}
                        alt={preset.label}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              </div>

              {/* Optional Backdrop Upload */}
              <div>
                <div className="flex items-center justify-between gap-2 mb-1">
                  <label className="block text-xs font-medium text-neutral-300">
                    Ifoto Nini ya Hero / Backdrop (Optional)
                  </label>
                  <label className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-xs font-semibold text-white cursor-pointer">
                    <ImagePlus className="w-3.5 h-3.5" />
                    <span>
                      {uploadingField === 'backdrop' ? 'Kohereza...' : 'Upload Backdrop'}
                    </span>
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/webp,image/gif"
                      className="hidden"
                      onChange={(e) => {
                        handleImageFileUpload(e.target.files?.[0], 'backdrop');
                        e.target.value = '';
                      }}
                    />
                  </label>
                </div>
                <input
                  type="text"
                  value={form.backdropUrl}
                  onChange={(e) => setForm({ ...form, backdropUrl: e.target.value })}
                  placeholder="https://... (niba ntayo, ikoresha ifoto ya poster)"
                  className="w-full px-3.5 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white focus:outline-none focus:border-[#E50914]"
                />
              </div>

              <div>
                <div className="flex items-center justify-between gap-2 mb-1">
                  <label className="block text-xs font-medium text-neutral-300">
                    Link yo Kureba (Watch Movie URL — MP4, YouTube, Drive, R2)
                  </label>
                  <label className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-[11px] font-semibold text-white cursor-pointer">
                    <Upload className="w-3 h-3" />
                    <span>
                      {uploadingField === 'watchUrl' ? 'Kohereza...' : 'Upload MP4'}
                    </span>
                    <input
                      type="file"
                      accept="video/*,.mp4,.webm,.m4v"
                      className="hidden"
                      onChange={(e) => {
                        handleMediaFileUpload(e.target.files?.[0], 'watchUrl');
                        e.target.value = '';
                      }}
                    />
                  </label>
                </div>
                <input
                  type="text"
                  value={form.watchUrl}
                  onChange={(e) => setForm({ ...form, watchUrl: e.target.value })}
                  placeholder="https://... (mp4 cyangwa embed link)"
                  className="w-full px-3.5 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white focus:outline-none focus:border-[#E50914]"
                />
              </div>

              <div>
                <div className="flex items-center justify-between gap-2 mb-1">
                  <label className="block text-xs font-medium text-neutral-300">
                    Link yo Gupakurura (Download URL — MP4 cyangwa ZIP)
                  </label>
                  <label className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-[11px] font-semibold text-white cursor-pointer">
                    <Upload className="w-3 h-3" />
                    <span>
                      {uploadingField === 'downloadUrl'
                        ? 'Kohereza...'
                        : 'Upload ZIP / MP4'}
                    </span>
                    <input
                      type="file"
                      accept=".zip,application/zip,video/*,.mp4"
                      className="hidden"
                      onChange={(e) => {
                        handleMediaFileUpload(e.target.files?.[0], 'downloadUrl');
                        e.target.value = '';
                      }}
                    />
                  </label>
                </div>
                <input
                  type="text"
                  value={form.downloadUrl}
                  onChange={(e) => setForm({ ...form, downloadUrl: e.target.value })}
                  placeholder="https://... (direct download cyangwa .zip link)"
                  className="w-full px-3.5 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white focus:outline-none focus:border-[#E50914]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1 flex items-center gap-1.5">
                  <Clapperboard className="w-3.5 h-3.5 text-[#E50914]" />
                  <span>Link ya Trailer (YouTube / MP4 Trailer URL)</span>
                </label>
                <input
                  type="text"
                  value={form.trailerUrl}
                  onChange={(e) => setForm({ ...form, trailerUrl: e.target.value })}
                  placeholder="https://www.youtube.com/watch?v=... cyangwa .mp4"
                  className="w-full px-3.5 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white focus:outline-none focus:border-[#E50914]"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">
                    Umwaka
                  </label>
                  <input
                    type="number"
                    value={form.year}
                    onChange={(e) =>
                      setForm({ ...form, year: Number(e.target.value) || 2026 })
                    }
                    className="w-full px-3 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white tabular-nums focus:outline-none focus:border-[#E50914]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">
                    Igihe Imara
                  </label>
                  <input
                    type="text"
                    value={form.duration}
                    onChange={(e) => setForm({ ...form, duration: e.target.value })}
                    placeholder="1h 55m"
                    className="w-full px-3 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white focus:outline-none focus:border-[#E50914]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">
                    Ikigero
                  </label>
                  <input
                    type="text"
                    value={form.rating}
                    onChange={(e) => setForm({ ...form, rating: e.target.value })}
                    placeholder="16+"
                    className="w-full px-3 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white focus:outline-none focus:border-[#E50914]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Ibisobanuro (Inkuru ya Filime)
                </label>
                <textarea
                  rows={3}
                  value={form.description}
                  onChange={(e) =>
                    setForm({ ...form, description: e.target.value })
                  }
                  placeholder="Andika incamake y'iyi filime mu Kinyarwanda..."
                  className="w-full px-3.5 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white focus:outline-none focus:border-[#E50914]"
                />
              </div>

              <div className="flex flex-wrap items-center gap-5 pt-1">
                <label className="inline-flex items-center gap-2 text-xs text-neutral-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.isNew}
                    onChange={(e) => setForm({ ...form, isNew: e.target.checked })}
                    className="accent-[#E50914] w-4 h-4"
                  />
                  <span>Shyira muri Films Nshya</span>
                </label>

                <label className="inline-flex items-center gap-2 text-xs text-neutral-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.isFeatured}
                    onChange={(e) =>
                      setForm({ ...form, isFeatured: e.target.checked })
                    }
                    className="accent-[#E50914] w-4 h-4"
                  />
                  <span>Erekana ku Ruhembe (Hero)</span>
                </label>
              </div>

              {/* Multi-Part / Episodes Manager (Available for BOTH Movies & Series!) */}
              <div className="pt-3 border-t border-white/10 space-y-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-white flex items-center gap-1.5">
                    <Tv className="w-3.5 h-3.5 text-[#E50914]" />
                    <span>
                      {form.type === 'series'
                        ? `Ibice bya Seri (${form.episodes.length})`
                        : `Ibice bya Filime (${form.episodes.length})`}
                    </span>
                  </span>
                  <div className="flex items-center gap-1.5">
                    {form.episodes.length === 0 && (
                      <button
                        type="button"
                        onClick={addTwoPartsPreset}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-[#E50914]/20 hover:bg-[#E50914]/35 text-xs text-white cursor-pointer"
                      >
                        <span>Gira Ibice 2</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={addEpisodeRow}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-xs text-white cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Ongeraho Igice</span>
                    </button>
                  </div>
                </div>

                <p className="text-[11px] text-neutral-400">
                  Niba filime ifite ibice bibiri (Part 1 & Part 2) cyangwa ari seri, byongeremo
                  hano kugira ngo umushyitsi abibone byose akanze kuri filime.
                </p>

                {form.episodes.map((ep, idx) => (
                  <div
                    key={ep.id}
                    className="p-3 rounded bg-[#111111] border border-white/10 space-y-2"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <input
                        type="text"
                        value={ep.title}
                        onChange={(e) =>
                          updateEpisodeField(idx, 'title', e.target.value)
                        }
                        placeholder="Izina ry'igice (urugero: Igice cya 1)"
                        className="flex-1 px-2.5 py-1.5 rounded bg-[#1A1A1A] border border-white/10 text-xs text-white"
                      />
                      <input
                        type="number"
                        value={ep.episodeNumber}
                        onChange={(e) =>
                          updateEpisodeField(
                            idx,
                            'episodeNumber',
                            Number(e.target.value) || 1
                          )
                        }
                        className="w-16 px-2 py-1.5 rounded bg-[#1A1A1A] border border-white/10 text-xs text-white tabular-nums"
                        title="Igice #"
                      />
                      <button
                        type="button"
                        onClick={() => removeEpisodeRow(idx)}
                        className="p-1 text-neutral-400 hover:text-red-400 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <input
                      type="text"
                      value={ep.watchUrl}
                      onChange={(e) =>
                        updateEpisodeField(idx, 'watchUrl', e.target.value)
                      }
                      placeholder="Watch URL y'iki gice"
                      className="w-full px-2.5 py-1.5 rounded bg-[#1A1A1A] border border-white/10 text-xs text-white"
                    />
                    <input
                      type="text"
                      value={ep.downloadUrl}
                      onChange={(e) =>
                        updateEpisodeField(idx, 'downloadUrl', e.target.value)
                      }
                      placeholder="Download URL y'iki gice"
                      className="w-full px-2.5 py-1.5 rounded bg-[#1A1A1A] border border-white/10 text-xs text-white"
                    />
                  </div>
                ))}
              </div>
            </div>

            {statusMsg && (
              <p className="text-xs text-emerald-400 font-medium flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{statusMsg}</span>
              </p>
            )}
            {errorMsg && (
              <p className="text-xs text-red-400 font-medium">{errorMsg}</p>
            )}

            <button
              type="submit"
              disabled={saving}
              className="w-full py-2.5 rounded bg-[#E50914] hover:bg-[#c80812] disabled:opacity-60 text-white font-semibold text-sm transition-colors cursor-pointer"
            >
              {saving
                ? 'Turimo Kubika...'
                : form.id
                  ? 'Bika Impinduka ku Rubuga'
                  : 'Shyira Filime ku Rubuga'}
            </button>
          </form>

          {/* Existing Catalog Table */}
          <div className="xl:col-span-7 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="text-lg font-bold text-white">
                Urutonde rwa Filime Ziriho ({filteredMovies.length})
              </h2>
              <input
                type="text"
                value={movieSearch}
                onChange={(e) => setMovieSearch(e.target.value)}
                placeholder="Shakisha filime cyangwa umusobanuzi..."
                className="w-full sm:w-64 px-3.5 py-2 rounded bg-[#1A1A1A] border border-white/15 text-xs text-white focus:outline-none focus:border-[#E50914]"
              />
            </div>

            <div className="rounded-xl border border-white/10 bg-[#1A1A1A] overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#141414] border-b border-white/10 text-neutral-400">
                    <tr>
                      <th className="py-3 px-4 font-semibold">Filime</th>
                      <th className="py-3 px-3 font-semibold">Ubwoko & Ibice</th>
                      <th className="py-3 px-3 font-semibold">Uwayisobanuye</th>
                      <th className="py-3 px-3 font-semibold text-right">Views</th>
                      <th className="py-3 px-4 font-semibold text-right">Ibikorwa</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/10">
                    {filteredMovies.map((m) => (
                      <tr key={m.id} className="hover:bg-white/5 transition-colors">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <img
                              src={m.posterUrl}
                              alt={m.title}
                              referrerPolicy="no-referrer"
                              className="w-9 h-12 rounded object-cover bg-neutral-900 shrink-0"
                            />
                            <div className="min-w-0">
                              <p className="font-semibold text-white truncate max-w-[200px]">
                                {m.title}
                              </p>
                              <p className="text-[11px] text-neutral-400">
                                {m.isNew ? 'Nshya · ' : ''}
                                {m.isFeatured ? 'Hero · ' : ''}
                                {m.trailerUrl ? 'Trailer · ' : ''}
                                {m.year}
                              </p>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-3 text-neutral-300">
                          {m.type === 'series' ? 'Seri' : 'Filime'} · {m.genre}
                          {m.episodes && m.episodes.length > 0
                            ? ` · Ibice ${m.episodes.length}`
                            : ''}
                        </td>
                        <td className="py-3 px-3 text-neutral-200">{m.translator}</td>
                        <td className="py-3 px-3 text-right font-mono tabular-nums text-neutral-200">
                          {formatNumber(m.views)}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="inline-flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => handleEditMovie(m)}
                              title="Hindura"
                              className="p-1.5 rounded bg-white/5 hover:bg-white/15 text-neutral-200 cursor-pointer"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteMovie(m.id)}
                              title="Siba"
                              className="p-1.5 rounded bg-white/5 hover:bg-red-500/20 text-red-400 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {filteredMovies.length === 0 && (
                      <tr>
                        <td colSpan={5} className="py-10 text-center text-neutral-500">
                          Nta filime ibonetse.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: TRANSLATORS (Add + Edit + Avatar Upload) */}
      {activeTab === 'translators' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <form
            onSubmit={handleSaveTranslator}
            className="lg:col-span-4 p-6 rounded-xl bg-[#1A1A1A] border border-white/10 space-y-4"
          >
            <div className="flex items-center justify-between gap-2">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Mic2 className="w-4 h-4 text-[#E50914]" />
                <span>
                  {trForm.id ? 'Hindura Umusobanuzi' : 'Ongeramo Umusobanuzi'}
                </span>
              </h2>
              {trForm.id && (
                <button
                  type="button"
                  onClick={() => {
                    setTrForm(EMPTY_TRANSLATOR_FORM);
                    setTrStatusMsg('');
                    setTrErrorMsg('');
                  }}
                  className="text-xs text-neutral-400 hover:text-white cursor-pointer"
                >
                  Hagarika
                </button>
              )}
            </div>

            {/* Avatar Photo Upload + Preview */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-medium text-neutral-300">
                  Ifoto y’Umusobanuzi
                </label>
                <label className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-xs font-semibold text-white cursor-pointer">
                  <ImagePlus className="w-3.5 h-3.5" />
                  <span>
                    {uploadingField === 'translatorAvatar'
                      ? 'Kohereza...'
                      : 'Upload Ifoto'}
                  </span>
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/webp,image/gif"
                    className="hidden"
                    onChange={(e) => {
                      handleImageFileUpload(e.target.files?.[0], 'translatorAvatar');
                      e.target.value = '';
                    }}
                  />
                </label>
              </div>

              <div className="flex items-center gap-3">
                {trForm.avatarUrl ? (
                  <img
                    src={trForm.avatarUrl}
                    alt="Ifoto y'umusobanuzi"
                    referrerPolicy="no-referrer"
                    className="w-12 h-12 rounded-full object-cover border border-white/15 shrink-0 bg-neutral-900"
                  />
                ) : (
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center text-white shrink-0"
                    style={{ backgroundColor: trForm.accentHex || '#E50914' }}
                  >
                    <Mic2 className="w-5 h-5" />
                  </div>
                )}
                <input
                  type="text"
                  value={trForm.avatarUrl}
                  onChange={(e) =>
                    setTrForm({ ...trForm, avatarUrl: e.target.value })
                  }
                  placeholder="https://... cyangwa upload ifoto"
                  className="flex-1 px-3 py-2 rounded bg-[#111111] border border-white/15 text-xs text-white focus:outline-none focus:border-[#E50914]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">
                Izina ry’Umusobanuzi *
              </label>
              <input
                type="text"
                required
                value={trForm.name}
                onChange={(e) => setTrForm({ ...trForm, name: e.target.value })}
                placeholder="Urugero: Yanga, PK, Gaheza..."
                className="w-full px-3.5 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white focus:outline-none focus:border-[#E50914]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Ibyo Akunda Gusobanura
                </label>
                <input
                  type="text"
                  value={trForm.specialty}
                  onChange={(e) =>
                    setTrForm({ ...trForm, specialty: e.target.value })
                  }
                  placeholder="Action & Imirwano"
                  className="w-full px-3 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white focus:outline-none focus:border-[#E50914]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Ibara Ryihariye
                </label>
                <input
                  type="color"
                  value={trForm.accentHex}
                  onChange={(e) =>
                    setTrForm({ ...trForm, accentHex: e.target.value })
                  }
                  className="w-full h-9 rounded bg-[#111111] border border-white/15 px-1 cursor-pointer"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">
                Incamake ye (Bio)
              </label>
              <textarea
                rows={3}
                value={trForm.bio}
                onChange={(e) => setTrForm({ ...trForm, bio: e.target.value })}
                placeholder="Ubusobanuro bugufi ku musobanuzi..."
                className="w-full px-3.5 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white focus:outline-none focus:border-[#E50914]"
              />
            </div>

            {trStatusMsg && (
              <p className="text-xs text-emerald-400 font-medium flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{trStatusMsg}</span>
              </p>
            )}
            {trErrorMsg && (
              <p className="text-xs text-red-400 font-medium">{trErrorMsg}</p>
            )}

            <button
              type="submit"
              disabled={savingTranslator}
              className="w-full py-2.5 rounded bg-[#E50914] hover:bg-[#c80812] disabled:opacity-60 text-white font-semibold text-sm cursor-pointer"
            >
              {savingTranslator
                ? 'Turimo Kubika...'
                : trForm.id
                  ? 'Bika Impinduka z’Umusobanuzi'
                  : 'Ongeramo Umusobanuzi'}
            </button>
          </form>

          <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {translators.map((tr) => (
              <div
                key={tr.id}
                className="p-5 rounded-xl bg-[#1A1A1A] border border-white/10 flex flex-col justify-between gap-4"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    {tr.avatarUrl ? (
                      <img
                        src={tr.avatarUrl}
                        alt={tr.name}
                        referrerPolicy="no-referrer"
                        className="w-11 h-11 rounded-full object-cover border border-white/15 shrink-0 bg-neutral-900"
                      />
                    ) : (
                      <div
                        className="w-11 h-11 rounded-full flex items-center justify-center text-white shrink-0"
                        style={{ backgroundColor: tr.accentHex || '#E50914' }}
                      >
                        <Mic2 className="w-4 h-4" />
                      </div>
                    )}
                    <div className="min-w-0">
                      <h3 className="font-bold text-white truncate">{tr.name}</h3>
                      <p className="text-xs text-neutral-400 truncate">
                        {tr.specialty}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleEditTranslator(tr)}
                      title="Hindura amakuru cyangwa ifoto"
                      className="p-1.5 rounded bg-white/5 hover:bg-white/15 text-neutral-200 cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteTranslator(tr.id)}
                      title="Siba"
                      className="p-1.5 rounded bg-white/5 hover:bg-red-500/20 text-red-400 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
                <p className="text-xs text-neutral-300 leading-relaxed">{tr.bio}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: ADS API & IP ANALYTICS */}
      {activeTab === 'ads_analytics' && (
        <div className="space-y-8">
          {/* KPI Strip */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 rounded-xl bg-[#1A1A1A] border border-white/10 space-y-1">
              <p className="text-xs text-neutral-400">Inshuro Zarebwe (Views)</p>
              <p className="text-2xl font-bold text-white font-mono tabular-nums">
                {formatNumber(analytics?.totalViews ?? 0)}
              </p>
            </div>
            <div className="p-5 rounded-xl bg-[#1A1A1A] border border-white/10 space-y-1">
              <p className="text-xs text-neutral-400">IP Addresses Zihariye</p>
              <p className="text-2xl font-bold text-white font-mono tabular-nums">
                {formatNumber(analytics?.uniqueIps ?? 0)}
              </p>
            </div>
            <div className="p-5 rounded-xl bg-[#1A1A1A] border border-white/10 space-y-1">
              <p className="text-xs text-neutral-400">Inshuro Zapakuruwe</p>
              <p className="text-2xl font-bold text-white font-mono tabular-nums">
                {formatNumber(analytics?.totalDownloads ?? 0)}
              </p>
            </div>
            <div className="p-5 rounded-xl bg-[#1A1A1A] border border-white/10 space-y-1">
              <p className="text-xs text-neutral-400">
                Inyungu Iteganyijwe (RPM ${(analytics?.rpmUsd ?? 2.5).toFixed(2)})
              </p>
              <p className="text-2xl font-bold text-emerald-400 font-mono tabular-nums">
                ${(analytics?.estimatedRevenueUsd ?? 0).toFixed(2)}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
            {/* Ads API Settings Form */}
            <form
              onSubmit={handleSaveAdsConfig}
              className="xl:col-span-5 p-6 rounded-xl bg-[#1A1A1A] border border-white/10 space-y-4"
            >
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Zap className="w-4 h-4 text-[#E50914]" />
                  <span>Igenamiterere rya Ads API</span>
                </h2>
                <label className="inline-flex items-center gap-2 text-xs text-neutral-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={adsConfig.enabled}
                    onChange={(e) =>
                      setAdsConfig({ ...adsConfig, enabled: e.target.checked })
                    }
                    className="accent-[#E50914] w-4 h-4"
                  />
                  <span>Bikora</span>
                </label>
              </div>

              <p className="text-xs text-neutral-400 leading-relaxed">
                Buri muntu wese ureba cyangwa upakurura filime, seriveri ibika{' '}
                <strong className="text-neutral-200">IP Address</strong> ye ikohereza amakuru
                kuri Ads API yawe kugira ngo ubone amafaranga ya views.
              </p>

              <div className="space-y-3">
                {/* Google AdSense Section */}
                <div className="p-3.5 rounded-lg bg-[#111111] border border-white/10 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">
                      Google AdSense / Google Ads
                    </span>
                    <label className="inline-flex items-center gap-1.5 text-[11px] text-neutral-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={adsConfig.adsenseAutoAds}
                        onChange={(e) =>
                          setAdsConfig({
                            ...adsConfig,
                            adsenseAutoAds: e.target.checked,
                          })
                        }
                        className="accent-[#E50914]"
                      />
                      <span>Auto Ads</span>
                    </label>
                  </div>
                  <div>
                    <label className="block text-[11px] text-neutral-400 mb-1">
                      Google AdSense Publisher ID (ca-pub-...)
                    </label>
                    <input
                      type="text"
                      value={adsConfig.adsenseClientId}
                      onChange={(e) =>
                        setAdsConfig({
                          ...adsConfig,
                          adsenseClientId: e.target.value,
                        })
                      }
                      placeholder="ca-pub-1234567890123456"
                      className="w-full px-3 py-1.5 rounded bg-[#1A1A1A] border border-white/15 text-xs text-white font-mono focus:outline-none focus:border-[#E50914]"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-neutral-400 mb-1">
                      AdSense Ad Slot ID
                    </label>
                    <input
                      type="text"
                      value={adsConfig.adsenseSlotId}
                      onChange={(e) =>
                        setAdsConfig({
                          ...adsConfig,
                          adsenseSlotId: e.target.value,
                        })
                      }
                      placeholder="1234567890"
                      className="w-full px-3 py-1.5 rounded bg-[#1A1A1A] border border-white/15 text-xs text-white font-mono focus:outline-none focus:border-[#E50914]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">
                    Ikigo cya Ads (Provider Name)
                  </label>
                  <input
                    type="text"
                    value={adsConfig.providerName}
                    onChange={(e) =>
                      setAdsConfig({ ...adsConfig, providerName: e.target.value })
                    }
                    placeholder="Google AdSense, Adsterra, Monetag..."
                    className="w-full px-3.5 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white focus:outline-none focus:border-[#E50914]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">
                    Ads API Endpoint URL (Webhook / Tracking Endpoint)
                  </label>
                  <div className="relative">
                    <Globe className="w-4 h-4 text-neutral-500 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={adsConfig.apiEndpointUrl}
                      onChange={(e) =>
                        setAdsConfig({ ...adsConfig, apiEndpointUrl: e.target.value })
                      }
                      placeholder="https://api.ads-provider.com/v1/impression"
                      className="w-full pl-9 pr-3.5 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white font-mono focus:outline-none focus:border-[#E50914]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">
                    Ads API Key / Publisher Token
                  </label>
                  <div className="relative">
                    <KeyRound className="w-4 h-4 text-neutral-500 absolute left-3 top-2.5" />
                    <input
                      type="password"
                      value={adsConfig.apiKey}
                      onChange={(e) =>
                        setAdsConfig({ ...adsConfig, apiKey: e.target.value })
                      }
                      placeholder="Shyiramo API key yawe"
                      className="w-full pl-9 pr-3.5 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white font-mono focus:outline-none focus:border-[#E50914]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-neutral-300 mb-1">
                      RPM ($ / 1,000 Views)
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={adsConfig.rpmUsd}
                      onChange={(e) =>
                        setAdsConfig({
                          ...adsConfig,
                          rpmUsd: Number(e.target.value) || 0,
                        })
                      }
                      className="w-full px-3 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white font-mono tabular-nums focus:outline-none focus:border-[#E50914]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-neutral-300 mb-1">
                      Pre-Roll (Amasegonda)
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={15}
                      value={adsConfig.preRollSeconds}
                      onChange={(e) =>
                        setAdsConfig({
                          ...adsConfig,
                          preRollSeconds: Number(e.target.value) || 0,
                        })
                      }
                      className="w-full px-3 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white font-mono tabular-nums focus:outline-none focus:border-[#E50914]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">
                    Sponsor Ad Banner Image URL (Optional)
                  </label>
                  <input
                    type="text"
                    value={adsConfig.adBannerImageUrl}
                    onChange={(e) =>
                      setAdsConfig({ ...adsConfig, adBannerImageUrl: e.target.value })
                    }
                    placeholder="https://..."
                    className="w-full px-3.5 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white focus:outline-none focus:border-[#E50914]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">
                    Sponsor Ad Click Link (Optional)
                  </label>
                  <input
                    type="text"
                    value={adsConfig.adBannerTargetUrl}
                    onChange={(e) =>
                      setAdsConfig({ ...adsConfig, adBannerTargetUrl: e.target.value })
                    }
                    placeholder="https://..."
                    className="w-full px-3.5 py-2 rounded bg-[#111111] border border-white/15 text-sm text-white focus:outline-none focus:border-[#E50914]"
                  />
                </div>
              </div>

              {adsTestResult && (
                <p className="text-xs text-neutral-200 bg-white/5 border border-white/10 rounded p-2.5">
                  {adsTestResult}
                </p>
              )}

              <div className="flex flex-wrap gap-3 pt-1">
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 rounded bg-[#E50914] hover:bg-[#c80812] text-white font-semibold text-sm cursor-pointer"
                >
                  Bika Igenamiterere
                </button>
                <button
                  type="button"
                  onClick={handleTestAdsApi}
                  className="py-2.5 px-4 rounded bg-white/10 hover:bg-white/20 text-white font-semibold text-xs cursor-pointer"
                >
                  Gerageza Ads API
                </button>
              </div>
            </form>

            {/* Viewer IP Address Tracking Table */}
            <div className="xl:col-span-7 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-bold text-white">
                    Amakuru ya IP Address & Views Zarebwe
                  </h2>
                  <p className="text-xs text-neutral-400">
                    Buri muntu urebye cyangwa upakuruwe abikwa n’IP ye kugira ngo aboneke muri Ads API.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={loadAdminData}
                    disabled={loadingAnalytics}
                    className="inline-flex items-center gap-1.5 px-3 py-2 rounded bg-white/10 hover:bg-white/20 text-xs font-semibold text-white cursor-pointer"
                  >
                    <RefreshCw
                      className={`w-3.5 h-3.5 ${loadingAnalytics ? 'animate-spin' : ''}`}
                    />
                    <span>Vugurura</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleExportCsv}
                    className="inline-flex items-center gap-1.5 px-3 py-2 rounded bg-white text-[#141414] hover:bg-neutral-200 text-xs font-bold cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Pakurura CSV</span>
                  </button>
                </div>
              </div>

              <div className="rounded-xl border border-white/10 bg-[#1A1A1A] overflow-hidden">
                <div className="overflow-x-auto max-h-[520px]">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#141414] border-b border-white/10 text-neutral-400 sticky top-0">
                      <tr>
                        <th className="py-3 px-4 font-semibold">IP Address</th>
                        <th className="py-3 px-3 font-semibold">Filime</th>
                        <th className="py-3 px-3 font-semibold">Igikorwa</th>
                        <th className="py-3 px-3 font-semibold">Ads API Status</th>
                        <th className="py-3 px-4 font-semibold text-right">Igihe</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/10">
                      {(analytics?.recentLogs ?? []).map((log) => (
                        <tr key={log.id} className="hover:bg-white/5">
                          <td className="py-2.5 px-4 font-mono tabular-nums text-white">
                            {log.ipAddress}
                          </td>
                          <td className="py-2.5 px-3 text-neutral-200 max-w-[180px] truncate">
                            {log.movieTitle}
                          </td>
                          <td className="py-2.5 px-3 text-neutral-300">
                            {log.eventType === 'download'
                              ? 'Pakurura'
                              : log.eventType === 'ad_impression'
                                ? 'Ad View'
                                : 'Reba Filime'}
                          </td>
                          <td className="py-2.5 px-3">
                            <span
                              className={
                                log.adsApiSynced ? 'text-emerald-400' : 'text-neutral-400'
                              }
                            >
                              {log.adsApiStatus}
                            </span>
                          </td>
                          <td className="py-2.5 px-4 text-right font-mono tabular-nums text-neutral-400">
                            {new Date(log.timestamp).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit',
                              second: '2-digit',
                            })}
                          </td>
                        </tr>
                      ))}
                      {(!analytics || analytics.recentLogs.length === 0) && (
                        <tr>
                          <td colSpan={5} className="py-12 text-center text-neutral-500">
                            Nta view irabikwa kugeza ubu. Reba cyangwa upakurure filime kugira
                            ngo IP Address ibikwe hano.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: CLOUDFLARE D1 & R2 + BULK IMPORT */}
      {activeTab === 'cloudflare' && (
        <div className="space-y-8">
          <div className="p-5 rounded-xl bg-[#1A1A1A] border border-white/10 space-y-2">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Cloud className="w-5 h-5 text-[#E50914]" />
              <span>Guhuza Cloudflare D1 (Database) & Cloudflare R2 (Ububiko Bunini)</span>
            </h2>
            <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed max-w-4xl">
              <strong className="text-white">Cloudflare D1</strong> ibika amakuru yose y’amafilime,
              abasobanuzi, na IP views kugira ngo devices zose zihore zibona amakuru amwe.{' '}
              <strong className="text-white">Cloudflare R2</strong> yo ni ububiko bunini bw’amafoto,
              dosiye za <code className="font-mono text-white">.zip</code>, na video za{' '}
              <code className="font-mono text-white">.mp4</code> zitishyuza egress bandwidth!
            </p>
          </div>

          {cfStatusMsg && (
            <div className="p-3.5 rounded-lg bg-[#1A1A1A] border border-white/15 text-xs text-neutral-100">
              {cfStatusMsg}
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
            {/* Cloudflare D1 Configuration */}
            <div className="p-6 rounded-xl bg-[#1A1A1A] border border-white/10 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Database className="w-4 h-4 text-[#E50914]" />
                  <span>1. Cloudflare D1 Database</span>
                </h3>
                <label className="inline-flex items-center gap-2 text-xs text-neutral-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={cfConfig.d1Enabled}
                    onChange={(e) =>
                      setCfConfig({ ...cfConfig, d1Enabled: e.target.checked })
                    }
                    className="accent-[#E50914] w-4 h-4"
                  />
                  <span>Koresha D1</span>
                </label>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">
                    Cloudflare Account ID
                  </label>
                  <input
                    type="text"
                    value={cfConfig.accountId}
                    onChange={(e) =>
                      setCfConfig({ ...cfConfig, accountId: e.target.value })
                    }
                    placeholder="urugero: 8a1b2c3d4e5f..."
                    className="w-full px-3.5 py-2 rounded bg-[#111111] border border-white/15 text-xs text-white font-mono focus:outline-none focus:border-[#E50914]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">
                    D1 Database ID
                  </label>
                  <input
                    type="text"
                    value={cfConfig.d1DatabaseId}
                    onChange={(e) =>
                      setCfConfig({ ...cfConfig, d1DatabaseId: e.target.value })
                    }
                    placeholder="UUID ya D1 database yawe"
                    className="w-full px-3.5 py-2 rounded bg-[#111111] border border-white/15 text-xs text-white font-mono focus:outline-none focus:border-[#E50914]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">
                    Cloudflare API Token (D1 Edit Permission)
                  </label>
                  <input
                    type="password"
                    value={cfConfig.apiToken}
                    onChange={(e) =>
                      setCfConfig({ ...cfConfig, apiToken: e.target.value })
                    }
                    placeholder="Bearer API Token"
                    className="w-full px-3.5 py-2 rounded bg-[#111111] border border-white/15 text-xs text-white font-mono focus:outline-none focus:border-[#E50914]"
                  />
                </div>
              </div>

              <div className="flex flex-wrap gap-2 pt-2">
                <button
                  type="button"
                  onClick={handleSaveAndTestD1}
                  className="px-4 py-2 rounded bg-[#E50914] hover:bg-[#c80812] text-white text-xs font-semibold cursor-pointer"
                >
                  Bika & Suzuma D1
                </button>
                <button
                  type="button"
                  onClick={() => handleSyncD1('push')}
                  className="px-3.5 py-2 rounded bg-white/10 hover:bg-white/20 text-white text-xs font-semibold cursor-pointer"
                >
                  Ohereza Amakuru kuri D1
                </button>
                <button
                  type="button"
                  onClick={() => handleSyncD1('pull')}
                  className="px-3.5 py-2 rounded bg-white/10 hover:bg-white/20 text-white text-xs font-semibold cursor-pointer"
                >
                  Kura Amakuru muri D1
                </button>
              </div>
            </div>

            {/* Cloudflare R2 Object Storage */}
            <div className="p-6 rounded-xl bg-[#1A1A1A] border border-white/10 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <HardDrive className="w-4 h-4 text-[#E50914]" />
                  <span>2. Cloudflare R2 Storage (Amafoto, ZIP & MP4)</span>
                </h3>
                <label className="inline-flex items-center gap-2 text-xs text-neutral-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={cfConfig.r2Enabled}
                    onChange={(e) =>
                      setCfConfig({ ...cfConfig, r2Enabled: e.target.checked })
                    }
                    className="accent-[#E50914] w-4 h-4"
                  />
                  <span>Koresha R2</span>
                </label>
              </div>

              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-neutral-300 mb-1">
                      R2 Bucket Name
                    </label>
                    <input
                      type="text"
                      value={cfConfig.r2BucketName}
                      onChange={(e) =>
                        setCfConfig({ ...cfConfig, r2BucketName: e.target.value })
                      }
                      placeholder="agasobanuye-media"
                      className="w-full px-3 py-2 rounded bg-[#111111] border border-white/15 text-xs text-white font-mono focus:outline-none focus:border-[#E50914]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-neutral-300 mb-1">
                      R2 Public URL (r2.dev / Domain)
                    </label>
                    <input
                      type="text"
                      value={cfConfig.r2PublicUrl}
                      onChange={(e) =>
                        setCfConfig({ ...cfConfig, r2PublicUrl: e.target.value })
                      }
                      placeholder="https://pub-xxxx.r2.dev"
                      className="w-full px-3 py-2 rounded bg-[#111111] border border-white/15 text-xs text-white font-mono focus:outline-none focus:border-[#E50914]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">
                    R2 Access Key ID
                  </label>
                  <input
                    type="text"
                    value={cfConfig.r2AccessKeyId}
                    onChange={(e) =>
                      setCfConfig({ ...cfConfig, r2AccessKeyId: e.target.value })
                    }
                    placeholder="Access Key ID ya R2"
                    className="w-full px-3.5 py-2 rounded bg-[#111111] border border-white/15 text-xs text-white font-mono focus:outline-none focus:border-[#E50914]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">
                    R2 Secret Access Key
                  </label>
                  <input
                    type="password"
                    value={cfConfig.r2SecretAccessKey}
                    onChange={(e) =>
                      setCfConfig({
                        ...cfConfig,
                        r2SecretAccessKey: e.target.value,
                      })
                    }
                    placeholder="Secret Access Key ya R2"
                    className="w-full px-3.5 py-2 rounded bg-[#111111] border border-white/15 text-xs text-white font-mono focus:outline-none focus:border-[#E50914]"
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleSaveAndTestR2}
                  className="px-4 py-2 rounded bg-[#E50914] hover:bg-[#c80812] text-white text-xs font-semibold cursor-pointer"
                >
                  Bika & Suzuma R2
                </button>

                <label className="inline-flex items-center gap-2 px-4 py-2 rounded bg-white text-[#141414] hover:bg-neutral-200 text-xs font-bold cursor-pointer">
                  <Upload className="w-3.5 h-3.5" />
                  <span>
                    {uploadingField === 'r2Quick'
                      ? 'Kohereza...'
                      : 'Upload ZIP / MP4 / Photo'}
                  </span>
                  <input
                    type="file"
                    accept=".zip,application/zip,video/*,image/*"
                    className="hidden"
                    onChange={(e) => {
                      handleMediaFileUpload(e.target.files?.[0], 'r2Quick');
                      e.target.value = '';
                    }}
                  />
                </label>
              </div>

              {r2QuickUrl && (
                <div className="p-2.5 rounded bg-[#111111] border border-white/10 text-[11px] font-mono text-emerald-400 break-all">
                  {r2QuickUrl}
                </div>
              )}
            </div>
          </div>

          {/* Bulk JSON Movie Importer */}
          <div className="p-6 rounded-xl bg-[#1A1A1A] border border-white/10 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-white">
                  3. Injiza Filime Nyinshi Icyarimwe (Bulk JSON Import)
                </h3>
                <p className="text-xs text-neutral-400">
                  Shyiramo urutonde rwa JSON rw’amafilime menshi icyarimwe utiriwe wandika imwe ku yindi.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowBulkImport((prev) => !prev)}
                className="px-3.5 py-2 rounded bg-white/10 hover:bg-white/20 text-xs font-semibold text-white cursor-pointer"
              >
                {showBulkImport ? 'Hisha' : 'Fungura Bulk Import'}
              </button>
            </div>

            {showBulkImport && (
              <div className="space-y-3">
                <textarea
                  rows={6}
                  value={bulkJsonText}
                  onChange={(e) => setBulkJsonText(e.target.value)}
                  placeholder='[{"title": "Filime Nshya", "type": "movie", "genre": "Action", "translator": "Yanga", "posterUrl": "https://...", "watchUrl": "https://...", "downloadUrl": "https://...", "trailerUrl": "https://..."}]'
                  className="w-full p-3.5 rounded bg-[#111111] border border-white/15 text-xs text-white font-mono focus:outline-none focus:border-[#E50914]"
                />
                {bulkStatusMsg && (
                  <p className="text-xs text-emerald-400">{bulkStatusMsg}</p>
                )}
                <button
                  type="button"
                  onClick={handleBulkImport}
                  className="px-5 py-2.5 rounded bg-[#E50914] hover:bg-[#c80812] text-white text-xs font-semibold cursor-pointer"
                >
                  Injiza Zose Icyarimwe
                </button>
              </div>
            )}
          </div>

          {/* Hosting Project ZIP Export */}
          <div className="p-6 rounded-xl bg-[#1A1A1A] border border-white/10 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="space-y-1 max-w-2xl">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Download className="w-4 h-4 text-[#E50914]" />
                  <span>4. Pakurura ZIP yo Guhostinga (Full-Stack Source ZIP)</span>
                </h3>
                <p className="text-xs text-neutral-300 leading-relaxed">
                  Iyi ZIP irimo code zose za Frontend (React/Vite) na Backend (Express{' '}
                  <code className="font-mono text-white">server.ts</code>), amafoto ya filime, na{' '}
                  <code className="font-mono text-white">data/db.json</code>. Yihostinge kuri{' '}
                  <strong className="text-white">Render.com, Railway, Koyeb, cyangwa VPS</strong>{' '}
                  ukoresheje <code className="font-mono text-white">npm install && npm run build</code>{' '}
                  na <code className="font-mono text-white">npm start</code>.
                </p>
              </div>

              <button
                type="button"
                onClick={handleExportProjectZip}
                disabled={exportingZip}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#E50914] hover:bg-[#c80812] disabled:opacity-60 text-white text-xs font-bold whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>
                  {exportingZip
                    ? 'Turi gutunganya ZIP...'
                    : 'Pakurura AgasobanuyeFree.zip'}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
