import { ArrowRight, Mic2 } from 'lucide-react';
import { useState } from 'react';
import type { MovieItem, TranslatorProfile } from '../types.ts';
import { formatNumber } from '../utils/video.ts';

interface TranslatorsDirectoryProps {
  translators: TranslatorProfile[];
  movies: MovieItem[];
  onSelectTranslator: (translatorName: string) => void;
}

function TranslatorAvatar({ tr }: { tr: TranslatorProfile }) {
  const [imgError, setImgError] = useState(false);

  if (tr.avatarUrl && !imgError) {
    return (
      <img
        src={tr.avatarUrl}
        alt={tr.name}
        referrerPolicy="no-referrer"
        onError={() => setImgError(true)}
        className="w-14 h-14 rounded-full object-cover border border-white/15 shrink-0 bg-neutral-900"
      />
    );
  }

  return (
    <div
      className="w-14 h-14 rounded-full flex items-center justify-center text-white font-bold text-lg shrink-0"
      style={{ backgroundColor: tr.accentHex || '#E50914' }}
    >
      <Mic2 className="w-5 h-5" />
    </div>
  );
}

export function TranslatorsDirectory({
  translators,
  movies,
  onSelectTranslator,
}: TranslatorsDirectoryProps) {
  return (
    <section className="max-w-[1440px] mx-auto px-4 sm:px-8 pt-24 pb-16 space-y-8">
      <div className="space-y-2 max-w-2xl">
        <h1 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
          Abasobanuzi b’Inzobere
        </h1>
        <p className="text-sm sm:text-base text-neutral-400">
          Hitamo umusobanuzi ukunda kugira ngo urebe amafilime n’amaseri yose yasobanuye ku buntu.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {translators.map((tr) => {
          const trMovies = movies.filter(
            (m) =>
              m.translator.toLowerCase().includes(tr.name.toLowerCase()) ||
              tr.name.toLowerCase().includes(m.translator.toLowerCase())
          );
          const totalViews = trMovies.reduce((sum, m) => sum + m.views, 0);

          return (
            <button
              key={tr.id}
              type="button"
              onClick={() => onSelectTranslator(tr.name)}
              className="group text-left p-6 rounded-lg bg-[#1A1A1A] border border-white/10 hover:border-white/30 transition-colors flex flex-col justify-between gap-5 cursor-pointer"
            >
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <TranslatorAvatar tr={tr} />
                  <div className="min-w-0">
                    <h2 className="text-lg font-bold text-white truncate">
                      {tr.name}
                    </h2>
                    <p className="text-xs text-neutral-400 truncate">
                      {tr.specialty}
                    </p>
                  </div>
                </div>

                <p className="text-sm text-neutral-300 leading-relaxed line-clamp-3">
                  {tr.bio}
                </p>
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 text-neutral-400 tabular-nums">
                  <span>{trMovies.length} Filime</span>
                  <span aria-hidden="true">·</span>
                  <span>{formatNumber(totalViews)} views</span>
                </div>
                <span className="inline-flex items-center gap-1 font-semibold text-white group-hover:text-[#E50914] transition-colors">
                  <span>Reba Zose</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
}
