import { useEffect, useRef } from 'react';
import type { PublicAdsConfig } from '../types.ts';

declare global {
  interface Window {
    adsbygoogle?: Array<Record<string, unknown>>;
  }
}

interface AdSenseSlotProps {
  adsConfig: PublicAdsConfig | null;
  className?: string;
}

export function AdSenseSlot({ adsConfig, className = '' }: AdSenseSlotProps) {
  const pushedRef = useRef(false);

  const clientId = adsConfig?.enabled ? adsConfig.adsenseClientId.trim() : '';
  const slotId = adsConfig?.enabled ? adsConfig.adsenseSlotId.trim() : '';

  useEffect(() => {
    if (!clientId) return;
    const existing = document.querySelector<HTMLScriptElement>(
      `script[data-adsense-client="${clientId}"]`
    );
    if (!existing) {
      const script = document.createElement('script');
      script.async = true;
      script.crossOrigin = 'anonymous';
      script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${encodeURIComponent(
        clientId
      )}`;
      script.setAttribute('data-adsense-client', clientId);
      document.head.appendChild(script);
    }
  }, [clientId]);

  useEffect(() => {
    if (!clientId || !slotId || pushedRef.current) return;
    try {
      (window.adsbygoogle = window.adsbygoogle || []).push({});
      pushedRef.current = true;
    } catch {
      // Ignore AdSense push errors when adblockers are active
    }
  }, [clientId, slotId]);

  if (!adsConfig?.enabled) return null;

  if (clientId && slotId) {
    return (
      <div
        className={`w-full overflow-hidden rounded-lg bg-[#111111] border border-white/10 p-2 ${className}`}
      >
        <p className="text-[10px] text-neutral-500 mb-1 px-1">Kwamamaza</p>
        <ins
          className="adsbygoogle"
          style={{ display: 'block' }}
          data-ad-client={clientId}
          data-ad-slot={slotId}
          data-ad-format="auto"
          data-full-width-responsive="true"
        />
      </div>
    );
  }

  if (adsConfig.adBannerImageUrl) {
    return (
      <a
        href={adsConfig.adBannerTargetUrl || '#'}
        target="_blank"
        rel="noopener noreferrer"
        className={`block w-full overflow-hidden rounded-lg border border-white/10 bg-[#111111] ${className}`}
      >
        <img
          src={adsConfig.adBannerImageUrl}
          alt="Kwamamaza"
          referrerPolicy="no-referrer"
          className="w-full max-h-28 object-cover"
        />
      </a>
    );
  }

  return null;
}
