import { Search, Sparkles, X } from 'lucide-react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AdminPanel } from './components/AdminPanel.tsx';
import { AdSenseSlot } from './components/AdSenseSlot.tsx';
import { HeroBillboard } from './components/HeroBillboard.tsx';
import { MovieCard } from './components/MovieCard.tsx';
import { MovieModal } from './components/MovieModal.tsx';
import { MovieRow } from './components/MovieRow.tsx';
import { Navbar, type NavSection } from './components/Navbar.tsx';
import { TranslatorsDirectory } from './components/TranslatorsDirectory.tsx';
import { GENRE_OPTIONS } from './data/seedData.ts';
import type {
  MovieItem,
  PublicAdsConfig,
  TranslatorProfile,
  ViewEventType,
} from './types.ts';

export default function App() {
  const [movies, setMovies] = useState<MovieItem[]>([]);
  const [translators, setTranslators] = useState<TranslatorProfile[]>([]);
  const [adsConfig, setAdsConfig] = useState<PublicAdsConfig | null>(null);
  const [loading, setLoading] = useState(true);

  const [activeSection, setActiveSection] = useState<NavSection>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState<string>('Byose');
  const [selectedTranslatorFilter, setSelectedTranslatorFilter] = useState<string>('');

  const [modalMovie, setModalMovie] = useState<MovieItem | null>(null);
  const [modalInitialPlay, setModalInitialPlay] = useState(false);
  const searchInputRef = useRef<HTMLInputElement | null>(null);

  const focusSearch = () => {
    const el = searchInputRef.current;
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      el.focus();
    }
  };

  const fetchCatalog = useCallback(async () => {
    try {
      const res = await fetch('/api/catalog');
      if (!res.ok) return;
      const data = (await res.json()) as {
        movies: MovieItem[];
        translators: TranslatorProfile[];
        ads: PublicAdsConfig;
      };
      setMovies(data.movies || []);
      setTranslators(data.translators || []);
      setAdsConfig(data.ads || null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchCatalog();
  }, [fetchCatalog]);

  const trackViewEvent = useCallback(
    async (movieId: string, eventType: ViewEventType) => {
      try {
        const res = await fetch('/api/views', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ movieId, eventType }),
        });
        if (res.ok) {
          const data = (await res.json()) as {
            movieViews: number;
            movieDownloads: number;
          };
          setMovies((prev) =>
            prev.map((m) =>
              m.id === movieId
                ? {
                    ...m,
                    views: data.movieViews ?? m.views,
                    downloads: data.movieDownloads ?? m.downloads,
                  }
                : m
            )
          );
        }
      } catch {
        // Non-blocking telemetry ping
      }
    },
    []
  );

  const openDetailModal = (movie: MovieItem) => {
    setModalInitialPlay(false);
    setModalMovie(movie);
  };

  const openWatchModal = (movie: MovieItem) => {
    setModalInitialPlay(true);
    setModalMovie(movie);
  };

  const featuredMovies = useMemo(() => {
    const featured = movies.filter((m) => m.isFeatured);
    return featured.length > 0 ? featured : movies.slice(0, 3);
  }, [movies]);

  const newReleases = useMemo(
    () => movies.filter((m) => m.isNew),
    [movies]
  );

  const trendingMovies = useMemo(
    () => [...movies].sort((a, b) => b.views - a.views),
    [movies]
  );

  const onlyMovies = useMemo(
    () => movies.filter((m) => m.type === 'movie'),
    [movies]
  );

  const onlySeries = useMemo(
    () => movies.filter((m) => m.type === 'series'),
    [movies]
  );

  const filteredCatalog = useMemo(() => {
    let base = movies;
    if (activeSection === 'movies') base = onlyMovies;
    if (activeSection === 'series') base = onlySeries;
    if (activeSection === 'new') base = newReleases;

    return base.filter((m) => {
      const matchesGenre =
        selectedGenre === 'Byose' ||
        m.genre.toLowerCase() === selectedGenre.toLowerCase();
      const matchesTranslator =
        !selectedTranslatorFilter ||
        m.translator.toLowerCase().includes(selectedTranslatorFilter.toLowerCase());
      const q = searchQuery.trim().toLowerCase();
      const matchesSearch =
        !q ||
        m.title.toLowerCase().includes(q) ||
        m.translator.toLowerCase().includes(q) ||
        m.genre.toLowerCase().includes(q);
      return matchesGenre && matchesTranslator && matchesSearch;
    });
  }, [
    movies,
    onlyMovies,
    onlySeries,
    newReleases,
    activeSection,
    selectedGenre,
    selectedTranslatorFilter,
    searchQuery,
  ]);

  const isFiltering =
    searchQuery.trim().length > 0 ||
    selectedGenre !== 'Byose' ||
    selectedTranslatorFilter.length > 0;

  const handleNavigate = (section: NavSection) => {
    setActiveSection(section);
    if (section !== 'admin') {
      fetchCatalog();
    }
    if (section !== 'movies' && section !== 'home') {
      setSelectedTranslatorFilter('');
    }
    if (section === 'home') {
      setSelectedGenre('Byose');
      setSelectedTranslatorFilter('');
      setSearchQuery('');
    }
  };

  const activeModalMovie = useMemo(() => {
    if (!modalMovie) return null;
    return movies.find((m) => m.id === modalMovie.id) || modalMovie;
  }, [modalMovie, movies]);

  const relatedMovies = useMemo(() => {
    if (!activeModalMovie) return [];
    return movies
      .filter(
        (m) =>
          m.id !== activeModalMovie.id &&
          (m.genre === activeModalMovie.genre ||
            m.translator === activeModalMovie.translator)
      )
      .slice(0, 4);
  }, [activeModalMovie, movies]);

  return (
    <div className="min-h-screen bg-[#141414] text-neutral-100 flex flex-col">
      <Navbar
        activeSection={activeSection}
        onNavigate={handleNavigate}
        onFocusSearch={focusSearch}
      />

      <main className="flex-1">
        {activeSection === 'admin' ? (
          <AdminPanel
            movies={movies}
            translators={translators}
            onRefreshCatalog={fetchCatalog}
            onViewWebsite={() => handleNavigate('home')}
          />
        ) : activeSection === 'translators' ? (
          <TranslatorsDirectory
            translators={translators}
            movies={movies}
            onSelectTranslator={(name) => {
              setSelectedTranslatorFilter(name);
              setActiveSection('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        ) : (
          <>
            {/* Show Hero Billboard on Home when not actively searching */}
            {activeSection === 'home' && !isFiltering && (
              <HeroBillboard
                featuredMovies={featuredMovies}
                onWatch={openWatchModal}
                onOpenDetail={openDetailModal}
              />
            )}

            {/* Search & Genre Filter Toolbar */}
            <section
              className={`max-w-[1440px] mx-auto px-4 sm:px-8 ${
                activeSection === 'home' && !isFiltering
                  ? 'pt-2 pb-4'
                  : 'pt-24 pb-6'
              }`}
            >
              {activeSection !== 'home' && (
                <div className="mb-6 space-y-1">
                  <h1 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
                    {activeSection === 'movies'
                      ? 'Filime Zisobanuye'
                      : activeSection === 'series'
                        ? 'Amaseri Asobanuye'
                        : 'Films Nshya Zasohotse'}
                  </h1>
                  <p className="text-sm text-neutral-400">
                    Reba cyangwa upakurure ku buntu nta kwiyandikisha bisabwa.
                  </p>
                </div>
              )}

              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 py-3 border-y border-white/10">
                {/* Genre Filter Buttons */}
                <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 lg:pb-0">
                  {['Byose', ...GENRE_OPTIONS].map((genre) => {
                    const active = selectedGenre === genre;
                    return (
                      <button
                        key={genre}
                        type="button"
                        onClick={() => setSelectedGenre(genre)}
                        className={`px-3.5 py-1.5 rounded text-xs font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                          active
                            ? 'bg-[#E50914] text-white'
                            : 'bg-white/5 text-neutral-300 hover:bg-white/10 hover:text-white'
                        }`}
                      >
                        {genre}
                      </button>
                    );
                  })}
                </div>

                {/* Live Search & Active Translator Filter */}
                <div className="flex flex-wrap items-center gap-3 shrink-0">
                  <select
                    aria-label="Hitamo Umusobanuzi"
                    value={selectedTranslatorFilter}
                    onChange={(e) => setSelectedTranslatorFilter(e.target.value)}
                    className="px-3 py-2 rounded bg-[#1F1F1F] border border-white/15 text-xs sm:text-sm text-neutral-200 focus:outline-none focus:border-[#E50914] cursor-pointer"
                  >
                    <option value="">Abasobanuzi Bose</option>
                    {translators.map((tr) => (
                      <option key={tr.id} value={tr.name}>
                        {tr.name}
                      </option>
                    ))}
                  </select>

                  {selectedTranslatorFilter && (
                    <button
                      type="button"
                      onClick={() => setSelectedTranslatorFilter('')}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded bg-white/10 text-xs text-white hover:bg-white/20 cursor-pointer"
                    >
                      <span>{selectedTranslatorFilter}</span>
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}

                  <div className="relative w-full sm:w-72">
                    <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
                    <input
                      ref={searchInputRef}
                      type="search"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Shakisha filime cyangwa umusobanuzi..."
                      className="w-full pl-9 pr-3 py-2 rounded bg-[#1F1F1F] border border-white/15 text-xs sm:text-sm text-white placeholder:text-neutral-500 focus:outline-none focus:border-[#E50914]"
                    />
                  </div>
                </div>
              </div>
            </section>

            {loading ? (
              <div className="max-w-[1440px] mx-auto px-4 sm:px-8 py-12 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div
                    key={i}
                    className="aspect-[3/4] rounded-md bg-white/5 animate-pulse"
                  />
                ))}
              </div>
            ) : activeSection === 'home' && !isFiltering ? (
              <div className="pb-16 space-y-2">
                {/* Films Nshya Dedicated Row */}
                <MovieRow
                  title="Films Nshya (New Releases)"
                  subtitle="Ibiheruka gusohoka bisobanuye neza"
                  movies={newReleases}
                  onSelect={openDetailModal}
                  onWatch={openWatchModal}
                  onViewAll={() => setActiveSection('new')}
                />

                {/* Trending */}
                <MovieRow
                  title="Filime Zikunzwe Cyane"
                  subtitle="Izirebwa kurusha izindi kuri AgasobanuyeFree"
                  movies={trendingMovies}
                  onSelect={openDetailModal}
                  onWatch={openWatchModal}
                />

                {/* Optional Google AdSense / Sponsor Ad Banner */}
                <div className="max-w-[1440px] mx-auto px-4 sm:px-8">
                  <AdSenseSlot adsConfig={adsConfig} />
                </div>

                {/* Movies Row */}
                <MovieRow
                  title="Filime Zisobanuye (Movies)"
                  movies={onlyMovies}
                  onSelect={openDetailModal}
                  onWatch={openWatchModal}
                  onViewAll={() => setActiveSection('movies')}
                />

                {/* Series Row */}
                <MovieRow
                  title="Seri Zisobanuye (Series)"
                  movies={onlySeries}
                  onSelect={openDetailModal}
                  onWatch={openWatchModal}
                  onViewAll={() => setActiveSection('series')}
                />

                {/* Action & Thriller Row */}
                <MovieRow
                  title="Action, Thriller & Sci-Fi"
                  movies={movies.filter((m) =>
                    ['Action', 'Thriller', 'Sci-Fi'].includes(m.genre)
                  )}
                  onSelect={openDetailModal}
                  onWatch={openWatchModal}
                />
              </div>
            ) : (
              /* Filtered / Dedicated Grid View (Filime, Seri, Films Nshya, Search Results) */
              <section className="max-w-[1440px] mx-auto px-4 sm:px-8 pb-20">
                {filteredCatalog.length > 0 ? (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 sm:gap-5">
                    {filteredCatalog.map((movie) => (
                      <MovieCard
                        key={movie.id}
                        movie={movie}
                        onSelect={openDetailModal}
                        onWatch={openWatchModal}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="py-20 text-center space-y-3 border border-white/10 rounded-xl bg-[#1A1A1A]">
                    <Sparkles className="w-8 h-8 text-[#E50914] mx-auto" />
                    <h3 className="text-lg font-bold text-white">
                      Nta filime ihuye n’ibyo ushakisha
                    </h3>
                    <p className="text-sm text-neutral-400">
                      Gerageza guhindura ijambo ushakisha cyangwa uhitemo ubwoko bwa "Byose".
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        setSearchQuery('');
                        setSelectedGenre('Byose');
                        setSelectedTranslatorFilter('');
                      }}
                      className="px-4 py-2 rounded bg-[#E50914] text-white text-xs font-semibold cursor-pointer"
                    >
                      Garura Filime Zose
                    </button>
                  </div>
                )}
              </section>
            )}
          </>
        )}
      </main>

      {/* Clean Kinyarwanda Footer */}
      <footer className="border-t border-white/10 bg-[#0d0d0d] pt-10 pb-24 md:pb-10">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <div className="text-xl font-extrabold tracking-tight leading-none">
              <span className="text-[#E50914]">Agasobanuye</span>
              <span className="text-white ml-0.5">Free</span>
            </div>
            <p className="text-xs text-neutral-400">
              Reba kandi upakurure amafilime n’amaseri asobanuye mu Kinyarwanda ku buntu — nta kwiyandikisha bisabwa.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-5 text-xs text-neutral-400">
            <button
              type="button"
              onClick={() => handleNavigate('home')}
              className="hover:text-white cursor-pointer"
            >
              Ahabanza
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('movies')}
              className="hover:text-white cursor-pointer"
            >
              Filime
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('series')}
              className="hover:text-white cursor-pointer"
            >
              Seri
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('new')}
              className="hover:text-white cursor-pointer"
            >
              Films Nshya
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('translators')}
              className="hover:text-white cursor-pointer"
            >
              Abasobanuzi
            </button>
          </div>
        </div>
      </footer>

      {/* Movie / Series Detail & Cinema Player Modal */}
      {activeModalMovie && (
        <MovieModal
          movie={activeModalMovie}
          initialPlay={modalInitialPlay}
          adsConfig={adsConfig}
          relatedMovies={relatedMovies}
          onClose={() => setModalMovie(null)}
          onSelectMovie={(m) => {
            setModalInitialPlay(false);
            setModalMovie(m);
          }}
          onTrackEvent={trackViewEvent}
        />
      )}
    </div>
  );
}
