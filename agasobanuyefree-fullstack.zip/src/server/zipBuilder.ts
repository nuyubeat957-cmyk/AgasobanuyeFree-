import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

export interface ZipInputEntry {
  name: string;
  data: Buffer;
  mtime?: Date;
}

const CRC32_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i += 1) {
    let c = i;
    for (let k = 0; k < 8; k += 1) {
      c = (c & 1) !== 0 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(buf: Buffer): number {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i += 1) {
    crc = CRC32_TABLE[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function toDosTimeDate(date: Date): { dosTime: number; dosDate: number } {
  const year = Math.max(1980, date.getFullYear());
  const month = date.getMonth() + 1;
  const day = date.getDate();
  const hours = date.getHours();
  const minutes = date.getMinutes();
  const seconds = Math.floor(date.getSeconds() / 2);

  const dosTime = (hours << 11) | (minutes << 5) | seconds;
  const dosDate = ((year - 1980) << 9) | (month << 5) | day;
  return { dosTime, dosDate };
}

export function buildZipBuffer(entries: ZipInputEntry[]): Buffer {
  const localChunks: Buffer[] = [];
  const centralChunks: Buffer[] = [];
  let offset = 0;

  for (const entry of entries) {
    const cleanName = entry.name.replace(/\\/g, '/').replace(/^\/+/, '');
    const nameBuf = Buffer.from(cleanName, 'utf8');
    const rawData = entry.data;
    const compressed = zlib.deflateRawSync(rawData, { level: 6 });
    const useStore = compressed.length >= rawData.length;
    const payload = useStore ? rawData : compressed;
    const method = useStore ? 0 : 8;
    const crc = crc32(rawData);
    const { dosTime, dosDate } = toDosTimeDate(entry.mtime || new Date());

    // Local File Header (30 bytes + filename)
    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(0x04034b50, 0);
    localHeader.writeUInt16LE(20, 4); // Version needed to extract (2.0)
    localHeader.writeUInt16LE(0x0800, 6); // UTF-8 filename flag
    localHeader.writeUInt16LE(method, 8);
    localHeader.writeUInt16LE(dosTime, 10);
    localHeader.writeUInt16LE(dosDate, 12);
    localHeader.writeUInt32LE(crc, 14);
    localHeader.writeUInt32LE(payload.length, 18);
    localHeader.writeUInt32LE(rawData.length, 22);
    localHeader.writeUInt16LE(nameBuf.length, 26);
    localHeader.writeUInt16LE(0, 28); // Extra field length

    localChunks.push(localHeader, nameBuf, payload);

    // Central Directory Header (46 bytes + filename)
    const centralHeader = Buffer.alloc(46);
    centralHeader.writeUInt32LE(0x02014b50, 0);
    centralHeader.writeUInt16LE(20, 4); // Version made by
    centralHeader.writeUInt16LE(20, 6); // Version needed
    centralHeader.writeUInt16LE(0x0800, 8); // UTF-8 flag
    centralHeader.writeUInt16LE(method, 10);
    centralHeader.writeUInt16LE(dosTime, 12);
    centralHeader.writeUInt16LE(dosDate, 14);
    centralHeader.writeUInt32LE(crc, 16);
    centralHeader.writeUInt32LE(payload.length, 20);
    centralHeader.writeUInt32LE(rawData.length, 24);
    centralHeader.writeUInt16LE(nameBuf.length, 28);
    centralHeader.writeUInt16LE(0, 30); // Extra length
    centralHeader.writeUInt16LE(0, 32); // Comment length
    centralHeader.writeUInt16LE(0, 34); // Disk start
    centralHeader.writeUInt16LE(0, 36); // Internal attrs
    centralHeader.writeUInt32LE(0, 38); // External attrs
    centralHeader.writeUInt32LE(offset, 42);

    centralChunks.push(centralHeader, nameBuf);

    offset += localHeader.length + nameBuf.length + payload.length;
  }

  const centralDirBuffer = Buffer.concat(centralChunks);

  // End of Central Directory Record (22 bytes)
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(0, 4); // Disk number
  eocd.writeUInt16LE(0, 6); // Start disk
  eocd.writeUInt16LE(entries.length, 8);
  eocd.writeUInt16LE(entries.length, 10);
  eocd.writeUInt32LE(centralDirBuffer.length, 12);
  eocd.writeUInt32LE(offset, 16);
  eocd.writeUInt16LE(0, 20); // Comment length

  return Buffer.concat([...localChunks, centralDirBuffer, eocd]);
}

const IGNORED_DIRS = new Set([
  'node_modules',
  'dist',
  '.git',
  '.next',
  '.cache',
  '.aistudio',
]);

const IGNORED_FILES = new Set([
  '.env',
  '.env.local',
  '.DS_Store',
]);

export function collectProjectFilesForZip(rootDir: string): ZipInputEntry[] {
  const entries: ZipInputEntry[] = [];

  function walk(currentDir: string, relBase: string): void {
    const items = fs.readdirSync(currentDir, { withFileTypes: true });
    for (const item of items) {
      if (item.isDirectory()) {
        if (IGNORED_DIRS.has(item.name)) continue;
        walk(
          path.join(currentDir, item.name),
          relBase ? `${relBase}/${item.name}` : item.name
        );
      } else if (item.isFile()) {
        if (IGNORED_FILES.has(item.name)) continue;
        const fullPath = path.join(currentDir, item.name);
        const relPath = relBase ? `${relBase}/${item.name}` : item.name;
        const stat = fs.statSync(fullPath);
        entries.push({
          name: relPath,
          data: fs.readFileSync(fullPath),
          mtime: stat.mtime,
        });
      }
    }
  }

  walk(rootDir, '');

  const hostingGuide = `# AgasobanuyeFree - Amabwiriza yo Guhostinga

1. Koresha Node.js v20+ (Render, Railway, Koyeb, Fly.io, cyangwa VPS).
2. Fungura iyi ZIP hanyuma winjire mu bubiko bwayo.
3. Kora ibi bikurikira kugira ngo itangire gukora:
   - npm install
   - npm run build
   - NODE_ENV=production npm start
4. Shiramo Environment Variables (optional, cyangwa uzishyiremo muri Admin Panel):
   - ADMIN_PASSCODE=admin2026
   - PORT=3000
   - CF_ACCOUNT_ID, CF_D1_DATABASE_ID, CF_API_TOKEN (Cloudflare D1)
   - CF_R2_BUCKET, CF_R2_ACCESS_KEY_ID, CF_R2_SECRET_ACCESS_KEY, CF_R2_PUBLIC_URL (Cloudflare R2)
`;

  entries.push({
    name: 'README-HOSTING.md',
    data: Buffer.from(hostingGuide, 'utf8'),
    mtime: new Date(),
  });

  return entries;
}
