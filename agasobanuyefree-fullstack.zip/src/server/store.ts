import fs from 'fs';
import path from 'path';
import {
  INITIAL_ADS_CONFIG,
  INITIAL_CLOUDFLARE_CONFIG,
  INITIAL_MOVIES,
  INITIAL_TRANSLATORS,
} from '../data/seedData.ts';
import type {
  AdsConfig,
  AnalyticsSummary,
  CloudflareConfig,
  DatabaseSchema,
  MovieItem,
  TranslatorProfile,
  ViewEventType,
  ViewLog,
} from '../types.ts';
import {
  deleteMovieInD1,
  deleteTranslatorInD1,
  insertViewLogInD1,
  pullCatalogFromD1,
  pushCatalogToD1,
  upsertAdsConfigInD1,
  upsertMovieInD1,
  upsertTranslatorInD1,
} from './cloudflare.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

function envCloudflareOverlay(base: CloudflareConfig): CloudflareConfig {
  const accountId = process.env.CF_ACCOUNT_ID || base.accountId;
  const d1DatabaseId = process.env.CF_D1_DATABASE_ID || base.d1DatabaseId;
  const apiToken = process.env.CF_API_TOKEN || base.apiToken;
  const r2BucketName = process.env.CF_R2_BUCKET || base.r2BucketName;
  const r2AccessKeyId = process.env.CF_R2_ACCESS_KEY_ID || base.r2AccessKeyId;
  const r2SecretAccessKey =
    process.env.CF_R2_SECRET_ACCESS_KEY || base.r2SecretAccessKey;
  const r2PublicUrl = process.env.CF_R2_PUBLIC_URL || base.r2PublicUrl;

  return {
    ...base,
    accountId,
    d1DatabaseId,
    apiToken,
    d1Enabled:
      base.d1Enabled || Boolean(process.env.CF_D1_DATABASE_ID && process.env.CF_API_TOKEN),
    r2BucketName,
    r2AccessKeyId,
    r2SecretAccessKey,
    r2PublicUrl,
    r2Enabled:
      base.r2Enabled ||
      Boolean(
        process.env.CF_R2_BUCKET &&
          process.env.CF_R2_ACCESS_KEY_ID &&
          process.env.CF_R2_SECRET_ACCESS_KEY
      ),
  };
}

function ensureDb(): DatabaseSchema {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const defaultCf = envCloudflareOverlay(INITIAL_CLOUDFLARE_CONFIG);

  if (!fs.existsSync(DB_FILE)) {
    const initial: DatabaseSchema = {
      movies: INITIAL_MOVIES,
      translators: INITIAL_TRANSLATORS,
      adsConfig: INITIAL_ADS_CONFIG,
      cloudflareConfig: defaultCf,
      viewLogs: [],
    };
    fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2), 'utf-8');
    return initial;
  }

  try {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    const parsed = JSON.parse(raw) as Partial<DatabaseSchema>;
    const loadedMovies = Array.isArray(parsed.movies)
      ? parsed.movies
      : INITIAL_MOVIES;
    const loadedTranslators = Array.isArray(parsed.translators)
      ? parsed.translators
      : INITIAL_TRANSLATORS;

    let changed = false;

    const migratedMovies = loadedMovies.map((m) => {
      if (m.translator === 'Gahenda') {
        changed = true;
        return { ...m, translator: 'Gaheza' };
      }
      return m;
    });

    const migratedTranslators = loadedTranslators.map((t) => {
      if (t.name === 'Gahenda' || t.id === 'tr-gahenda') {
        changed = true;
        return { ...t, id: 'tr-gaheza', name: 'Gaheza', nickname: 'Gaheza Classic' };
      }
      return t;
    });

    for (const seedTr of INITIAL_TRANSLATORS) {
      const exists = migratedTranslators.some(
        (t) =>
          t.id === seedTr.id ||
          t.name.toLowerCase() === seedTr.name.toLowerCase()
      );
      if (!exists) {
        migratedTranslators.push(seedTr);
        changed = true;
      }
    }

    const cfCfg = envCloudflareOverlay(
      parsed.cloudflareConfig
        ? { ...INITIAL_CLOUDFLARE_CONFIG, ...parsed.cloudflareConfig }
        : INITIAL_CLOUDFLARE_CONFIG
    );

    const hydrated: DatabaseSchema = {
      movies: migratedMovies,
      translators: migratedTranslators,
      adsConfig: parsed.adsConfig
        ? { ...INITIAL_ADS_CONFIG, ...parsed.adsConfig }
        : INITIAL_ADS_CONFIG,
      cloudflareConfig: cfCfg,
      viewLogs: Array.isArray(parsed.viewLogs) ? parsed.viewLogs : [],
    };

    if (changed) {
      fs.writeFileSync(DB_FILE, JSON.stringify(hydrated, null, 2), 'utf-8');
    }

    return hydrated;
  } catch {
    const fallback: DatabaseSchema = {
      movies: INITIAL_MOVIES,
      translators: INITIAL_TRANSLATORS,
      adsConfig: INITIAL_ADS_CONFIG,
      cloudflareConfig: defaultCf,
      viewLogs: [],
    };
    fs.writeFileSync(DB_FILE, JSON.stringify(fallback, null, 2), 'utf-8');
    return fallback;
  }
}

let state: DatabaseSchema = ensureDb();

function persist(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const tmpFile = `${DB_FILE}.tmp`;
  fs.writeFileSync(tmpFile, JSON.stringify(state, null, 2), 'utf-8');
  fs.renameSync(tmpFile, DB_FILE);
}

export async function initCloudflareOnStartup(): Promise<void> {
  const cfg = state.cloudflareConfig;
  if (!cfg.d1Enabled || !cfg.accountId || !cfg.d1DatabaseId || !cfg.apiToken) {
    return;
  }
  const pulled = await pullCatalogFromD1(cfg);
  if (!pulled.ok) return;

  if (pulled.movies && pulled.movies.length > 0) {
    state.movies = pulled.movies;
    if (pulled.translators && pulled.translators.length > 0) {
      state.translators = pulled.translators;
    }
    if (pulled.adsConfig) {
      state.adsConfig = { ...INITIAL_ADS_CONFIG, ...pulled.adsConfig };
    }
    if (pulled.viewLogs && pulled.viewLogs.length > 0) {
      state.viewLogs = pulled.viewLogs;
    }
    persist();
  } else {
    // Seed empty D1 database with current catalog
    await pushCatalogToD1(cfg, {
      movies: state.movies,
      translators: state.translators,
      adsConfig: state.adsConfig,
      viewLogs: state.viewLogs,
    });
  }
}

export function getMovies(): MovieItem[] {
  return [...state.movies].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
}

export function getMovieById(id: string): MovieItem | undefined {
  return state.movies.find((m) => m.id === id);
}

export function createMovie(
  input: Omit<MovieItem, 'id' | 'views' | 'downloads' | 'createdAt'>
): MovieItem {
  const newMovie: MovieItem = {
    ...input,
    id: `mov-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    views: 0,
    downloads: 0,
    createdAt: new Date().toISOString(),
  };
  state.movies.unshift(newMovie);
  persist();
  upsertMovieInD1(state.cloudflareConfig, newMovie).catch(() => {});
  return newMovie;
}

export function bulkCreateMovies(
  items: Array<Omit<MovieItem, 'id' | 'views' | 'downloads' | 'createdAt'>>
): MovieItem[] {
  const created: MovieItem[] = items.map((input, idx) => ({
    ...input,
    id: `mov-${Date.now()}-${idx}-${Math.random().toString(36).slice(2, 6)}`,
    views: 0,
    downloads: 0,
    createdAt: new Date(Date.now() + idx).toISOString(),
  }));
  state.movies = [...created, ...state.movies];
  persist();
  for (const m of created) {
    upsertMovieInD1(state.cloudflareConfig, m).catch(() => {});
  }
  return created;
}

export function updateMovie(
  id: string,
  updates: Partial<Omit<MovieItem, 'id' | 'createdAt'>>
): MovieItem | null {
  const idx = state.movies.findIndex((m) => m.id === id);
  if (idx === -1) return null;
  state.movies[idx] = {
    ...state.movies[idx],
    ...updates,
  };
  persist();
  upsertMovieInD1(state.cloudflareConfig, state.movies[idx]).catch(() => {});
  return state.movies[idx];
}

export function deleteMovie(id: string): boolean {
  const prevLen = state.movies.length;
  state.movies = state.movies.filter((m) => m.id !== id);
  if (state.movies.length !== prevLen) {
    persist();
    deleteMovieInD1(state.cloudflareConfig, id).catch(() => {});
    return true;
  }
  return false;
}

export function getTranslators(): TranslatorProfile[] {
  return [...state.translators];
}

export function createTranslator(
  input: Omit<TranslatorProfile, 'id'>
): TranslatorProfile {
  const created: TranslatorProfile = {
    ...input,
    id: `tr-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
  };
  state.translators.push(created);
  persist();
  upsertTranslatorInD1(state.cloudflareConfig, created).catch(() => {});
  return created;
}

export function updateTranslator(
  id: string,
  updates: Partial<Omit<TranslatorProfile, 'id'>>
): TranslatorProfile | null {
  const idx = state.translators.findIndex((t) => t.id === id);
  if (idx === -1) return null;
  const oldName = state.translators[idx].name;
  const updated: TranslatorProfile = {
    ...state.translators[idx],
    ...updates,
  };
  state.translators[idx] = updated;

  if (updates.name && updates.name.trim() && updates.name !== oldName) {
    state.movies = state.movies.map((m) => {
      if (m.translator === oldName) {
        const nextMovie = { ...m, translator: updates.name!.trim() };
        upsertMovieInD1(state.cloudflareConfig, nextMovie).catch(() => {});
        return nextMovie;
      }
      return m;
    });
  }
  persist();
  upsertTranslatorInD1(state.cloudflareConfig, updated).catch(() => {});
  return updated;
}

export function deleteTranslator(id: string): boolean {
  const prevLen = state.translators.length;
  state.translators = state.translators.filter((t) => t.id !== id);
  if (state.translators.length !== prevLen) {
    persist();
    deleteTranslatorInD1(state.cloudflareConfig, id).catch(() => {});
    return true;
  }
  return false;
}

export function getAdsConfig(): AdsConfig {
  return { ...state.adsConfig };
}

export function updateAdsConfig(updates: Partial<AdsConfig>): AdsConfig {
  state.adsConfig = {
    ...state.adsConfig,
    ...updates,
  };
  persist();
  upsertAdsConfigInD1(state.cloudflareConfig, state.adsConfig).catch(() => {});
  return { ...state.adsConfig };
}

export function getCloudflareConfig(): CloudflareConfig {
  return { ...state.cloudflareConfig };
}

export function updateCloudflareConfig(
  updates: Partial<CloudflareConfig>
): CloudflareConfig {
  state.cloudflareConfig = {
    ...state.cloudflareConfig,
    ...updates,
  };
  persist();
  return { ...state.cloudflareConfig };
}

export async function pushAllStateToCloudflareD1(): Promise<{
  ok: boolean;
  error?: string;
}> {
  return pushCatalogToD1(state.cloudflareConfig, {
    movies: state.movies,
    translators: state.translators,
    adsConfig: state.adsConfig,
    viewLogs: state.viewLogs,
  });
}

export async function pullAllStateFromCloudflareD1(): Promise<{
  ok: boolean;
  countMovies?: number;
  error?: string;
}> {
  const pulled = await pullCatalogFromD1(state.cloudflareConfig);
  if (!pulled.ok) return { ok: false, error: pulled.error };

  if (pulled.movies && pulled.movies.length > 0) {
    state.movies = pulled.movies;
  }
  if (pulled.translators && pulled.translators.length > 0) {
    state.translators = pulled.translators;
  }
  if (pulled.adsConfig) {
    state.adsConfig = { ...INITIAL_ADS_CONFIG, ...pulled.adsConfig };
  }
  if (pulled.viewLogs && pulled.viewLogs.length > 0) {
    state.viewLogs = pulled.viewLogs;
  }
  persist();
  return { ok: true, countMovies: pulled.movies?.length ?? 0 };
}

export async function recordViewEvent(params: {
  movieId: string;
  eventType: ViewEventType;
  ipAddress: string;
  userAgent: string;
}): Promise<{ log: ViewLog; movieViews: number; movieDownloads: number }> {
  const movie = state.movies.find((m) => m.id === params.movieId);
  const movieTitle = movie ? movie.title : 'Filime Itazwi';

  if (movie) {
    if (params.eventType === 'download') {
      movie.downloads += 1;
    } else {
      movie.views += 1;
    }
    upsertMovieInD1(state.cloudflareConfig, movie).catch(() => {});
  }

  let adsApiSynced = false;
  let adsApiStatus = 'IP Yabitswe kuri Seriveri';

  const ads = state.adsConfig;
  if (ads.enabled && ads.apiEndpointUrl && /^https?:\/\//i.test(ads.apiEndpointUrl)) {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 3500);
      const response = await fetch(ads.apiEndpointUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(ads.apiKey ? { Authorization: `Bearer ${ads.apiKey}` } : {}),
        },
        body: JSON.stringify({
          provider: ads.providerName,
          apiKey: ads.apiKey,
          ipAddress: params.ipAddress,
          movieId: params.movieId,
          movieTitle,
          eventType: params.eventType,
          timestamp: new Date().toISOString(),
        }),
        signal: controller.signal,
      });
      clearTimeout(timeout);
      adsApiSynced = response.ok;
      adsApiStatus = response.ok
        ? `Yoherejwe (${response.status})`
        : `Ikosa rya Ads API (${response.status})`;
    } catch {
      adsApiSynced = false;
      adsApiStatus = 'Ads API Ntiyabashije Kugaragara';
    }
  } else if (ads.enabled && ads.adsenseClientId) {
    adsApiSynced = true;
    adsApiStatus = `Google AdSense (${ads.adsenseClientId})`;
  } else if (!ads.enabled) {
    adsApiStatus = 'Ads Ifunze';
  }

  const log: ViewLog = {
    id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    ipAddress: params.ipAddress,
    userAgent: params.userAgent.slice(0, 140),
    movieId: params.movieId,
    movieTitle,
    eventType: params.eventType,
    adsApiSynced,
    adsApiStatus,
    timestamp: new Date().toISOString(),
  };

  state.viewLogs.unshift(log);
  if (state.viewLogs.length > 2500) {
    state.viewLogs = state.viewLogs.slice(0, 2500);
  }
  persist();
  insertViewLogInD1(state.cloudflareConfig, log).catch(() => {});

  return {
    log,
    movieViews: movie?.views ?? 0,
    movieDownloads: movie?.downloads ?? 0,
  };
}

export function getAnalyticsSummary(): AnalyticsSummary {
  const totalCatalogViews = state.movies.reduce((acc, m) => acc + m.views, 0);
  const totalCatalogDownloads = state.movies.reduce(
    (acc, m) => acc + m.downloads,
    0
  );
  const adImpressions = state.viewLogs.filter(
    (l) => l.eventType === 'ad_impression' || l.eventType === 'watch'
  ).length;

  const uniqueIpSet = new Set(state.viewLogs.map((l) => l.ipAddress));
  const rpm = state.adsConfig.rpmUsd || 2.5;
  const estimatedRevenueUsd = Number(((totalCatalogViews / 1000) * rpm).toFixed(2));

  const ipMap = new Map<
    string,
    { ipAddress: string; totalEvents: number; lastSeen: string; lastMovie: string }
  >();
  for (const log of state.viewLogs) {
    const existing = ipMap.get(log.ipAddress);
    if (!existing) {
      ipMap.set(log.ipAddress, {
        ipAddress: log.ipAddress,
        totalEvents: 1,
        lastSeen: log.timestamp,
        lastMovie: log.movieTitle,
      });
    } else {
      existing.totalEvents += 1;
    }
  }

  const topMovies = [...state.movies]
    .sort((a, b) => b.views - a.views)
    .slice(0, 8)
    .map((m) => ({
      id: m.id,
      title: m.title,
      translator: m.translator,
      type: m.type,
      views: m.views,
      downloads: m.downloads,
    }));

  return {
    totalViews: totalCatalogViews,
    uniqueIps: uniqueIpSet.size,
    totalDownloads: totalCatalogDownloads,
    adImpressions,
    estimatedRevenueUsd,
    rpmUsd: rpm,
    recentLogs: state.viewLogs.slice(0, 120),
    topMovies,
    ipBreakdown: Array.from(ipMap.values()).slice(0, 50),
  };
}

export function getAllViewLogs(): ViewLog[] {
  return [...state.viewLogs];
}
