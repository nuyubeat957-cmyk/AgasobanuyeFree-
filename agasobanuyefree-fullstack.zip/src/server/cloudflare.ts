import {
  HeadBucketCommand,
  PutObjectCommand,
  S3Client,
} from '@aws-sdk/client-s3';
import type {
  AdsConfig,
  CloudflareConfig,
  MovieItem,
  TranslatorProfile,
  ViewLog,
} from '../types.ts';

interface D1ApiResponse<T = Record<string, unknown>> {
  success: boolean;
  errors?: Array<{ message: string }>;
  result?: Array<{
    success: boolean;
    results?: T[];
  }>;
}

export async function queryCloudflareD1<T = Record<string, unknown>>(
  cfg: CloudflareConfig,
  sql: string,
  params: Array<string | number | null> = []
): Promise<{ ok: boolean; rows: T[]; error?: string }> {
  if (!cfg.accountId || !cfg.d1DatabaseId || !cfg.apiToken) {
    return {
      ok: false,
      rows: [],
      error: 'Account ID, D1 Database ID, na API Token birakenewe.',
    };
  }

  const endpoint = `https://api.cloudflare.com/client/v4/accounts/${encodeURIComponent(
    cfg.accountId.trim()
  )}/d1/database/${encodeURIComponent(cfg.d1DatabaseId.trim())}/query`;

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${cfg.apiToken.trim()}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ sql, params }),
    });

    const data = (await res.json()) as D1ApiResponse<T>;
    if (!res.ok || !data.success) {
      const msg =
        data.errors?.[0]?.message || `Cloudflare D1 HTTP ${res.status}`;
      return { ok: false, rows: [], error: msg };
    }

    const firstResult = data.result?.[0];
    return {
      ok: true,
      rows: firstResult?.results ?? [],
    };
  } catch (err) {
    return {
      ok: false,
      rows: [],
      error: err instanceof Error ? err.message : 'Ikosa rya Cloudflare D1',
    };
  }
}

export async function initCloudflareD1Tables(
  cfg: CloudflareConfig
): Promise<{ ok: boolean; error?: string }> {
  const statements = [
    `CREATE TABLE IF NOT EXISTS movies (
      id TEXT PRIMARY KEY,
      payload TEXT NOT NULL,
      created_at TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS translators (
      id TEXT PRIMARY KEY,
      payload TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      payload TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS view_logs (
      id TEXT PRIMARY KEY,
      ip_address TEXT NOT NULL,
      movie_id TEXT NOT NULL,
      movie_title TEXT NOT NULL,
      event_type TEXT NOT NULL,
      ads_api_synced INTEGER NOT NULL,
      ads_api_status TEXT NOT NULL,
      user_agent TEXT NOT NULL,
      timestamp TEXT NOT NULL
    )`,
  ];

  for (const sql of statements) {
    const res = await queryCloudflareD1(cfg, sql);
    if (!res.ok) return res;
  }
  return { ok: true };
}

export async function upsertMovieInD1(
  cfg: CloudflareConfig,
  movie: MovieItem
): Promise<void> {
  if (!cfg.d1Enabled) return;
  await queryCloudflareD1(
    cfg,
    `INSERT OR REPLACE INTO movies (id, payload, created_at) VALUES (?, ?, ?)`,
    [movie.id, JSON.stringify(movie), movie.createdAt]
  );
}

export async function deleteMovieInD1(
  cfg: CloudflareConfig,
  id: string
): Promise<void> {
  if (!cfg.d1Enabled) return;
  await queryCloudflareD1(cfg, `DELETE FROM movies WHERE id = ?`, [id]);
}

export async function upsertTranslatorInD1(
  cfg: CloudflareConfig,
  translator: TranslatorProfile
): Promise<void> {
  if (!cfg.d1Enabled) return;
  await queryCloudflareD1(
    cfg,
    `INSERT OR REPLACE INTO translators (id, payload) VALUES (?, ?)`,
    [translator.id, JSON.stringify(translator)]
  );
}

export async function deleteTranslatorInD1(
  cfg: CloudflareConfig,
  id: string
): Promise<void> {
  if (!cfg.d1Enabled) return;
  await queryCloudflareD1(cfg, `DELETE FROM translators WHERE id = ?`, [id]);
}

export async function upsertAdsConfigInD1(
  cfg: CloudflareConfig,
  adsConfig: AdsConfig
): Promise<void> {
  if (!cfg.d1Enabled) return;
  await queryCloudflareD1(
    cfg,
    `INSERT OR REPLACE INTO settings (key, payload) VALUES (?, ?)`,
    ['ads_config', JSON.stringify(adsConfig)]
  );
}

export async function insertViewLogInD1(
  cfg: CloudflareConfig,
  log: ViewLog
): Promise<void> {
  if (!cfg.d1Enabled) return;
  await queryCloudflareD1(
    cfg,
    `INSERT OR REPLACE INTO view_logs (id, ip_address, movie_id, movie_title, event_type, ads_api_synced, ads_api_status, user_agent, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      log.id,
      log.ipAddress,
      log.movieId,
      log.movieTitle,
      log.eventType,
      log.adsApiSynced ? 1 : 0,
      log.adsApiStatus,
      log.userAgent,
      log.timestamp,
    ]
  );
}

export async function pushCatalogToD1(
  cfg: CloudflareConfig,
  data: {
    movies: MovieItem[];
    translators: TranslatorProfile[];
    adsConfig: AdsConfig;
    viewLogs: ViewLog[];
  }
): Promise<{ ok: boolean; error?: string }> {
  const init = await initCloudflareD1Tables(cfg);
  if (!init.ok) return init;

  for (const movie of data.movies) {
    const r = await queryCloudflareD1(
      cfg,
      `INSERT OR REPLACE INTO movies (id, payload, created_at) VALUES (?, ?, ?)`,
      [movie.id, JSON.stringify(movie), movie.createdAt]
    );
    if (!r.ok) return r;
  }

  for (const tr of data.translators) {
    const r = await queryCloudflareD1(
      cfg,
      `INSERT OR REPLACE INTO translators (id, payload) VALUES (?, ?)`,
      [tr.id, JSON.stringify(tr)]
    );
    if (!r.ok) return r;
  }

  const adsRes = await queryCloudflareD1(
    cfg,
    `INSERT OR REPLACE INTO settings (key, payload) VALUES (?, ?)`,
    ['ads_config', JSON.stringify(data.adsConfig)]
  );
  if (!adsRes.ok) return adsRes;

  for (const log of data.viewLogs.slice(0, 100)) {
    await queryCloudflareD1(
      cfg,
      `INSERT OR REPLACE INTO view_logs (id, ip_address, movie_id, movie_title, event_type, ads_api_synced, ads_api_status, user_agent, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        log.id,
        log.ipAddress,
        log.movieId,
        log.movieTitle,
        log.eventType,
        log.adsApiSynced ? 1 : 0,
        log.adsApiStatus,
        log.userAgent,
        log.timestamp,
      ]
    );
  }

  return { ok: true };
}

export async function pullCatalogFromD1(cfg: CloudflareConfig): Promise<{
  ok: boolean;
  movies?: MovieItem[];
  translators?: TranslatorProfile[];
  adsConfig?: AdsConfig;
  viewLogs?: ViewLog[];
  error?: string;
}> {
  const init = await initCloudflareD1Tables(cfg);
  if (!init.ok) return { ok: false, error: init.error };

  const [mRes, tRes, sRes, lRes] = await Promise.all([
    queryCloudflareD1<{ payload: string }>(
      cfg,
      `SELECT payload FROM movies ORDER BY created_at DESC`
    ),
    queryCloudflareD1<{ payload: string }>(
      cfg,
      `SELECT payload FROM translators`
    ),
    queryCloudflareD1<{ key: string; payload: string }>(
      cfg,
      `SELECT key, payload FROM settings WHERE key = 'ads_config'`
    ),
    queryCloudflareD1<{
      id: string;
      ip_address: string;
      movie_id: string;
      movie_title: string;
      event_type: string;
      ads_api_synced: number;
      ads_api_status: string;
      user_agent: string;
      timestamp: string;
    }>(cfg, `SELECT * FROM view_logs ORDER BY timestamp DESC LIMIT 250`),
  ]);

  if (!mRes.ok) return { ok: false, error: mRes.error };

  const movies: MovieItem[] = [];
  for (const row of mRes.rows) {
    try {
      movies.push(JSON.parse(row.payload) as MovieItem);
    } catch {
      // skip malformed
    }
  }

  const translators: TranslatorProfile[] = [];
  for (const row of tRes.rows) {
    try {
      translators.push(JSON.parse(row.payload) as TranslatorProfile);
    } catch {
      // skip malformed
    }
  }

  let adsConfig: AdsConfig | undefined;
  if (sRes.rows[0]?.payload) {
    try {
      adsConfig = JSON.parse(sRes.rows[0].payload) as AdsConfig;
    } catch {
      // ignore
    }
  }

  const viewLogs: ViewLog[] = lRes.rows.map((row) => ({
    id: row.id,
    ipAddress: row.ip_address,
    movieId: row.movie_id,
    movieTitle: row.movie_title,
    eventType:
      row.event_type === 'download' || row.event_type === 'ad_impression'
        ? row.event_type
        : 'watch',
    adsApiSynced: Boolean(row.ads_api_synced),
    adsApiStatus: row.ads_api_status,
    userAgent: row.user_agent,
    timestamp: row.timestamp,
  }));

  return { ok: true, movies, translators, adsConfig, viewLogs };
}

function createR2Client(cfg: CloudflareConfig): S3Client {
  return new S3Client({
    region: 'auto',
    endpoint: `https://${cfg.accountId.trim()}.r2.cloudflarestorage.com`,
    credentials: {
      accessKeyId: cfg.r2AccessKeyId.trim(),
      secretAccessKey: cfg.r2SecretAccessKey.trim(),
    },
  });
}

export async function testCloudflareR2(
  cfg: CloudflareConfig
): Promise<{ ok: boolean; error?: string }> {
  if (
    !cfg.accountId ||
    !cfg.r2BucketName ||
    !cfg.r2AccessKeyId ||
    !cfg.r2SecretAccessKey
  ) {
    return {
      ok: false,
      error:
        'Account ID, R2 Bucket Name, Access Key ID, na Secret Access Key birakenewe.',
    };
  }
  try {
    const client = createR2Client(cfg);
    await client.send(
      new HeadBucketCommand({ Bucket: cfg.r2BucketName.trim() })
    );
    return { ok: true };
  } catch (err) {
    return {
      ok: false,
      error:
        err instanceof Error ? err.message : 'Ntibishobotse guhuza na Cloudflare R2',
    };
  }
}

export async function uploadBufferToR2(
  cfg: CloudflareConfig,
  params: {
    key: string;
    body: Buffer;
    contentType: string;
  }
): Promise<{ ok: boolean; url?: string; error?: string }> {
  if (
    !cfg.r2Enabled ||
    !cfg.accountId ||
    !cfg.r2BucketName ||
    !cfg.r2AccessKeyId ||
    !cfg.r2SecretAccessKey
  ) {
    return { ok: false, error: 'Cloudflare R2 ntabwo ifunguye.' };
  }

  try {
    const client = createR2Client(cfg);
    await client.send(
      new PutObjectCommand({
        Bucket: cfg.r2BucketName.trim(),
        Key: params.key,
        Body: params.body,
        ContentType: params.contentType,
      })
    );

    const base = cfg.r2PublicUrl.trim().replace(/\/$/, '');
    const url = base
      ? `${base}/${params.key}`
      : `https://${cfg.r2BucketName.trim()}.${cfg.accountId.trim()}.r2.cloudflarestorage.com/${params.key}`;

    return { ok: true, url };
  } catch (err) {
    return {
      ok: false,
      error: err instanceof Error ? err.message : 'Ikosa ryo kohereza kuri R2',
    };
  }
}
