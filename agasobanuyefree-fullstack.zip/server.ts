import 'dotenv/config';
import express from 'express';
import fs from 'fs';
import path from 'path';
import {
  initCloudflareD1Tables,
  testCloudflareR2,
  uploadBufferToR2,
} from './src/server/cloudflare.ts';
import {
  bulkCreateMovies,
  createMovie,
  createTranslator,
  deleteMovie,
  deleteTranslator,
  getAdsConfig,
  getAllViewLogs,
  getAnalyticsSummary,
  getCloudflareConfig,
  getMovieById,
  getMovies,
  getTranslators,
  initCloudflareOnStartup,
  pullAllStateFromCloudflareD1,
  pushAllStateToCloudflareD1,
  recordViewEvent,
  updateAdsConfig,
  updateCloudflareConfig,
  updateMovie,
  updateTranslator,
} from './src/server/store.ts';
import {
  buildZipBuffer,
  collectProjectFilesForZip,
} from './src/server/zipBuilder.ts';
import type { ViewEventType } from './src/types.ts';

function resolvePort(): number {
  const args = process.argv.slice(2);
  for (let i = 0; i < args.length; i += 1) {
    if (args[i] === '--port' && args[i + 1]) {
      const parsed = Number(args[i + 1]);
      if (!Number.isNaN(parsed) && parsed > 0) return parsed;
    }
    if (args[i].startsWith('--port=')) {
      const parsed = Number(args[i].split('=')[1]);
      if (!Number.isNaN(parsed) && parsed > 0) return parsed;
    }
  }
  if (process.env.NODE_ENV === 'production' && process.env.PORT) {
    return Number(process.env.PORT) || 3000;
  }
  return 3000;
}

const PORT = resolvePort();
const ADMIN_PASSCODE = process.env.ADMIN_PASSCODE || 'admin2026';

function extractClientIp(req: express.Request): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string' && forwarded.length > 0) {
    return forwarded.split(',')[0].trim();
  }
  if (Array.isArray(forwarded) && forwarded.length > 0) {
    return forwarded[0].trim();
  }
  const realIp = req.headers['x-real-ip'];
  if (typeof realIp === 'string' && realIp.length > 0) {
    return realIp.trim();
  }
  const raw = req.ip || req.socket.remoteAddress || '127.0.0.1';
  return raw.replace(/^::ffff:/, '');
}

function requireAdmin(
  req: express.Request,
  res: express.Response,
  next: express.NextFunction
): void {
  const code = req.headers['x-admin-passcode'];
  if (code !== ADMIN_PASSCODE) {
    res.status(401).json({ error: 'Ijambo ry’ibanga rya Admin si ryo.' });
    return;
  }
  next();
}

async function startServer(): Promise<void> {
  await initCloudflareOnStartup().catch(() => {});

  const app = express();
  app.set('trust proxy', true);

  const uploadsDir = path.resolve(process.cwd(), 'data', 'uploads');
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }
  app.use('/uploads', express.static(uploadsDir));

  // Raw file upload endpoint (supports large .zip, .mp4, .webm, or image uploads to Cloudflare R2 or local /uploads)
  app.post(
    '/api/admin/upload-file',
    requireAdmin,
    express.raw({ type: '*/*', limit: '250mb' }),
    async (req, res) => {
      const buffer = req.body as Buffer;
      if (!Buffer.isBuffer(buffer) || buffer.length === 0) {
        res.status(400).json({ error: 'Hitamo dosiye yo kohereza.' });
        return;
      }

      const rawName = String(req.headers['x-file-name'] || 'file.bin').replace(
        /[^a-zA-Z0-9._-]/g,
        '_'
      );
      const contentType = String(
        req.headers['content-type'] || 'application/octet-stream'
      );
      const safeKey = `media/${Date.now()}-${Math.random()
        .toString(36)
        .slice(2, 7)}-${rawName}`;

      const cfCfg = getCloudflareConfig();
      if (cfCfg.r2Enabled) {
        const r2Res = await uploadBufferToR2(cfCfg, {
          key: safeKey,
          body: buffer,
          contentType,
        });
        if (!r2Res.ok || !r2Res.url) {
          res.status(502).json({
            error: r2Res.error || 'Ntibishobotse kohereza muri Cloudflare R2.',
          });
          return;
        }
        res.status(201).json({ url: r2Res.url, storage: 'cloudflare-r2' });
        return;
      }

      const localName = `${Date.now()}-${rawName}`;
      fs.writeFileSync(path.join(uploadsDir, localName), buffer);
      res.status(201).json({ url: `/uploads/${localName}`, storage: 'local' });
    }
  );

  app.use(express.json({ limit: '12mb' }));

  // Public catalog endpoints (zero registration required)
  app.get('/api/catalog', (_req, res) => {
    const movies = getMovies();
    const translators = getTranslators();
    const ads = getAdsConfig();
    res.json({
      movies,
      translators,
      ads: {
        enabled: ads.enabled,
        providerName: ads.providerName,
        vastOrBannerUrl: ads.vastOrBannerUrl,
        adBannerImageUrl: ads.adBannerImageUrl,
        adBannerTargetUrl: ads.adBannerTargetUrl,
        preRollSeconds: ads.preRollSeconds,
        adsenseClientId: ads.adsenseClientId,
        adsenseSlotId: ads.adsenseSlotId,
        adsenseAutoAds: ads.adsenseAutoAds,
      },
    });
  });

  app.get('/api/movies/:id', (req, res) => {
    const movie = getMovieById(req.params.id);
    if (!movie) {
      res.status(404).json({ error: 'Filime ntibonetse.' });
      return;
    }
    res.json(movie);
  });

  // Track viewer IP address + view / download / ad impression for monetization
  app.post('/api/views', async (req, res) => {
    const { movieId, eventType } = req.body as {
      movieId?: string;
      eventType?: ViewEventType;
    };
    if (!movieId || !eventType) {
      res.status(400).json({ error: 'Amakuru ya filime arakenewe.' });
      return;
    }
    const validType: ViewEventType =
      eventType === 'download' || eventType === 'ad_impression'
        ? eventType
        : 'watch';
    const ipAddress = extractClientIp(req);
    const userAgent = req.headers['user-agent'] || 'Unknown';
    const result = await recordViewEvent({
      movieId,
      eventType: validType,
      ipAddress,
      userAgent,
    });
    res.json({
      ok: true,
      ipAddress,
      ...result,
    });
  });

  // Admin auth check
  app.post('/api/admin/login', (req, res) => {
    const { passcode } = req.body as { passcode?: string };
    if (passcode === ADMIN_PASSCODE) {
      res.json({ ok: true });
      return;
    }
    res.status(401).json({ error: 'Ijambo ry’ibanga si ryo. Ongera ugerageze.' });
  });

  // Admin movie CRUD
  app.post('/api/admin/movies', requireAdmin, (req, res) => {
    const body = req.body;
    if (!body?.title || !body?.translator || !body?.genre) {
      res
        .status(400)
        .json({ error: 'Izina, uwayisobanuye, n’ubwoko bwa filime birakenewe.' });
      return;
    }
    const created = createMovie({
      title: String(body.title).trim(),
      type: body.type === 'series' ? 'series' : 'movie',
      genre: String(body.genre).trim(),
      translator: String(body.translator).trim(),
      posterUrl:
        String(body.posterUrl || '').trim() ||
        '/src/assets/images/poster_action_revenge_1794979378449.jpg',
      backdropUrl:
        String(body.backdropUrl || body.posterUrl || '').trim() ||
        '/src/assets/images/hero_action_kigali_1794979378548.jpg',
      watchUrl: String(body.watchUrl || '').trim(),
      downloadUrl: String(body.downloadUrl || '').trim(),
      trailerUrl: String(body.trailerUrl || '').trim(),
      description:
        String(body.description || '').trim() ||
        'Filime nziza isobanuye neza mu Kinyarwanda ku buntu.',
      year: Number(body.year) || 2026,
      duration: String(body.duration || '1h 50m').trim(),
      rating: String(body.rating || '16+').trim(),
      isNew: Boolean(body.isNew),
      isFeatured: Boolean(body.isFeatured),
      episodes: Array.isArray(body.episodes) ? body.episodes : [],
    });
    res.status(201).json(created);
  });

  app.post('/api/admin/movies/bulk-import', requireAdmin, (req, res) => {
    const { items } = req.body as { items?: Array<Record<string, unknown>> };
    if (!Array.isArray(items) || items.length === 0) {
      res.status(400).json({ error: 'Shyiramo urutonde rwa filime.' });
      return;
    }
    const normalized = items
      .filter((it) => it && typeof it.title === 'string' && it.title.trim())
      .map((it) => ({
        title: String(it.title).trim(),
        type: (it.type === 'series' ? 'series' : 'movie') as 'movie' | 'series',
        genre: String(it.genre || 'Action').trim(),
        translator: String(it.translator || 'Rocky Kirabiranya').trim(),
        posterUrl:
          String(it.posterUrl || '').trim() ||
          '/src/assets/images/poster_action_revenge_1794979378449.jpg',
        backdropUrl:
          String(it.backdropUrl || it.posterUrl || '').trim() ||
          '/src/assets/images/hero_action_kigali_1794979378548.jpg',
        watchUrl: String(it.watchUrl || '').trim(),
        downloadUrl: String(it.downloadUrl || '').trim(),
        trailerUrl: String(it.trailerUrl || '').trim(),
        description:
          String(it.description || '').trim() ||
          'Filime nziza isobanuye neza mu Kinyarwanda ku buntu.',
        year: Number(it.year) || 2026,
        duration: String(it.duration || '1h 50m').trim(),
        rating: String(it.rating || '16+').trim(),
        isNew: it.isNew !== false,
        isFeatured: Boolean(it.isFeatured),
        episodes: Array.isArray(it.episodes) ? it.episodes : [],
      }));

    if (normalized.length === 0) {
      res.status(400).json({ error: 'Nta filime yujuje ibisabwa yabonetse.' });
      return;
    }

    const created = bulkCreateMovies(normalized);
    res.status(201).json({ count: created.length, items: created });
  });

  app.put('/api/admin/movies/:id', requireAdmin, (req, res) => {
    const updated = updateMovie(req.params.id, req.body);
    if (!updated) {
      res.status(404).json({ error: 'Filime ntibonetse.' });
      return;
    }
    res.json(updated);
  });

  app.delete('/api/admin/movies/:id', requireAdmin, (req, res) => {
    const deleted = deleteMovie(req.params.id);
    if (!deleted) {
      res.status(404).json({ error: 'Filime ntibonetse.' });
      return;
    }
    res.json({ ok: true });
  });

  // Admin image upload endpoint (routes to Cloudflare R2 if enabled, else local /uploads)
  app.post('/api/admin/upload-image', requireAdmin, async (req, res) => {
    const { dataUrl } = req.body as { filename?: string; dataUrl?: string };
    if (!dataUrl || typeof dataUrl !== 'string') {
      res.status(400).json({ error: 'Ifoto irakenewe.' });
      return;
    }
    const match = dataUrl.match(
      /^data:image\/(png|jpeg|jpg|webp|gif);base64,(.+)$/i
    );
    if (!match) {
      res
        .status(400)
        .json({ error: 'Hitamo ifoto nyayo (PNG, JPG, WEBP, GIF).' });
      return;
    }
    const rawExt = match[1].toLowerCase();
    const ext = rawExt === 'jpeg' ? 'jpg' : rawExt;
    const buffer = Buffer.from(match[2], 'base64');
    if (buffer.length > 8 * 1024 * 1024) {
      res.status(400).json({ error: 'Ifoto ntigomba kurenza 8MB.' });
      return;
    }
    const fileName = `img-${Date.now()}-${Math.random()
      .toString(36)
      .slice(2, 7)}.${ext}`;

    const cfCfg = getCloudflareConfig();
    if (cfCfg.r2Enabled) {
      const r2Res = await uploadBufferToR2(cfCfg, {
        key: `images/${fileName}`,
        body: buffer,
        contentType: `image/${ext === 'jpg' ? 'jpeg' : ext}`,
      });
      if (r2Res.ok && r2Res.url) {
        res.status(201).json({ url: r2Res.url, storage: 'cloudflare-r2' });
        return;
      }
    }

    const targetPath = path.join(uploadsDir, fileName);
    fs.writeFileSync(targetPath, buffer);
    res.status(201).json({ url: `/uploads/${fileName}`, storage: 'local' });
  });

  // Admin translator CRUD
  app.post('/api/admin/translators', requireAdmin, (req, res) => {
    const body = req.body;
    if (!body?.name) {
      res.status(400).json({ error: 'Izina ry’umusobanuzi rirakenewe.' });
      return;
    }
    const created = createTranslator({
      name: String(body.name).trim(),
      nickname: String(body.nickname || body.name).trim(),
      specialty: String(body.specialty || 'Action & Drama').trim(),
      bio: String(body.bio || 'Umusobanuzi w’umuhanga mu Kinyarwanda.').trim(),
      accentHex: String(body.accentHex || '#E50914').trim(),
      avatarUrl: String(body.avatarUrl || '').trim(),
    });
    res.status(201).json(created);
  });

  app.put('/api/admin/translators/:id', requireAdmin, (req, res) => {
    const body = req.body;
    const updated = updateTranslator(req.params.id, {
      ...(body.name !== undefined ? { name: String(body.name).trim() } : {}),
      ...(body.nickname !== undefined
        ? { nickname: String(body.nickname).trim() }
        : {}),
      ...(body.specialty !== undefined
        ? { specialty: String(body.specialty).trim() }
        : {}),
      ...(body.bio !== undefined ? { bio: String(body.bio).trim() } : {}),
      ...(body.accentHex !== undefined
        ? { accentHex: String(body.accentHex).trim() }
        : {}),
      ...(body.avatarUrl !== undefined
        ? { avatarUrl: String(body.avatarUrl).trim() }
        : {}),
    });
    if (!updated) {
      res.status(404).json({ error: 'Umusobanuzi ntabonetse.' });
      return;
    }
    res.json(updated);
  });

  app.delete('/api/admin/translators/:id', requireAdmin, (req, res) => {
    const deleted = deleteTranslator(req.params.id);
    if (!deleted) {
      res.status(404).json({ error: 'Umusobanuzi ntabonetse.' });
      return;
    }
    res.json({ ok: true });
  });

  // Admin Cloudflare D1 & R2 configuration
  app.get('/api/admin/cloudflare-config', requireAdmin, (_req, res) => {
    res.json(getCloudflareConfig());
  });

  app.put('/api/admin/cloudflare-config', requireAdmin, (req, res) => {
    const updated = updateCloudflareConfig(req.body);
    res.json(updated);
  });

  app.post('/api/admin/cloudflare-d1-test', requireAdmin, async (req, res) => {
    const updated = updateCloudflareConfig(req.body || {});
    const init = await initCloudflareD1Tables(updated);
    if (!init.ok) {
      res.json({ ok: false, message: init.error || 'D1 yanze guhura.' });
      return;
    }
    res.json({
      ok: true,
      message:
        'Cloudflare D1 yahujwe neza kandi amatebule (movies, translators, settings, view_logs) yaremwe!',
    });
  });

  app.post('/api/admin/cloudflare-d1-sync', requireAdmin, async (req, res) => {
    const { direction } = req.body as { direction?: 'push' | 'pull' };
    if (direction === 'pull') {
      const pulled = await pullAllStateFromCloudflareD1();
      res.json({
        ok: pulled.ok,
        message: pulled.ok
          ? `Amakuru yakuwe muri Cloudflare D1 neza (${pulled.countMovies ?? 0} filime).`
          : pulled.error || 'Byanze gukura amakuru muri D1.',
      });
      return;
    }
    const pushed = await pushAllStateToCloudflareD1();
    res.json({
      ok: pushed.ok,
      message: pushed.ok
        ? 'Amakuru yose yoherejwe neza muri Cloudflare D1!'
        : pushed.error || 'Byanze kohereza amakuru muri D1.',
    });
  });

  app.post('/api/admin/cloudflare-r2-test', requireAdmin, async (req, res) => {
    const updated = updateCloudflareConfig(req.body || {});
    const testRes = await testCloudflareR2(updated);
    res.json({
      ok: testRes.ok,
      message: testRes.ok
        ? 'Cloudflare R2 Bucket yahujwe neza! Ubu amafoto, .zip na .mp4 bizajya bibikwa muri R2.'
        : testRes.error || 'Byanze guhuza na Cloudflare R2.',
    });
  });

  // Admin Ads API config & test
  app.get('/api/admin/ads-config', requireAdmin, (_req, res) => {
    res.json(getAdsConfig());
  });

  app.put('/api/admin/ads-config', requireAdmin, (req, res) => {
    const updated = updateAdsConfig(req.body);
    res.json(updated);
  });

  app.post('/api/admin/ads-test', requireAdmin, async (req, res) => {
    const { apiEndpointUrl, apiKey, providerName } = req.body as {
      apiEndpointUrl?: string;
      apiKey?: string;
      providerName?: string;
    };
    if (!apiEndpointUrl || !/^https?:\/\//i.test(apiEndpointUrl)) {
      res.status(400).json({
        ok: false,
        message:
          'Shyiramo Ads API URL yuzuye itangizwa na https:// cyangwa http://.',
      });
      return;
    }
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);
      const response = await fetch(apiEndpointUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {}),
        },
        body: JSON.stringify({
          test: true,
          provider: providerName || 'AgasobanuyeFree',
          ipAddress: extractClientIp(req),
          eventType: 'ad_impression',
          timestamp: new Date().toISOString(),
        }),
        signal: controller.signal,
      });
      clearTimeout(timeout);
      res.json({
        ok: response.ok,
        status: response.status,
        message: response.ok
          ? `Ads API yakiriye neza ubutumwa (HTTP ${response.status}).`
          : `Ads API yasubije ikosa HTTP ${response.status}.`,
      });
    } catch (err) {
      res.json({
        ok: false,
        message: `Ntibishobotse guhuza na Ads API: ${err instanceof Error ? err.message : 'Ikosa'}`,
      });
    }
  });

  // Admin analytics & CSV export
  app.get('/api/admin/analytics', requireAdmin, (_req, res) => {
    res.json(getAnalyticsSummary());
  });

  app.get('/api/admin/export-logs', requireAdmin, (_req, res) => {
    const logs = getAllViewLogs();
    const header =
      'Timestamp,IP_Address,Movie_Title,Event_Type,Ads_API_Synced,Ads_API_Status\n';
    const rows = logs
      .map((l) =>
        [
          l.timestamp,
          l.ipAddress,
          `"${l.movieTitle.replace(/"/g, '""')}"`,
          l.eventType,
          String(l.adsApiSynced),
          `"${l.adsApiStatus.replace(/"/g, '""')}"`,
        ].join(',')
      )
      .join('\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader(
      'Content-Disposition',
      'attachment; filename="agasobanuyefree-ip-views.csv"'
    );
    res.send(header + rows);
  });

  // Export clean runnable full-stack project ZIP for hosting
  app.get('/api/admin/export-project-zip', requireAdmin, (_req, res) => {
    try {
      const entries = collectProjectFilesForZip(process.cwd());
      const zipBuffer = buildZipBuffer(entries);
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader(
        'Content-Disposition',
        'attachment; filename="agasobanuyefree-fullstack.zip"'
      );
      res.setHeader('Content-Length', String(zipBuffer.length));
      res.send(zipBuffer);
    } catch (err) {
      res.status(500).json({
        error: `Ntibishobotse gukora ZIP: ${err instanceof Error ? err.message : 'Ikosa'}`,
      });
    }
  });

  // Mount Vite middleware in dev or serve static dist in production
  const isProd = process.env.NODE_ENV === 'production';
  const distDir = path.resolve(process.cwd(), 'dist');

  if (isProd && fs.existsSync(distDir)) {
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AgasobanuyeFree server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
