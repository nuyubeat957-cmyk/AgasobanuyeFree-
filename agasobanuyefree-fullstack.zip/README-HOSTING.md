# AgasobanuyeFree - Amabwiriza yo Guhostinga

1. Koresha Node.js v20+ (Render, Railway, Koyeb, Fly.io, cyangwa VPS).
2. Fungura iyi ZIP hanyuma winjire mu bubiko bwayo.
3. Kora ibi bikurikira kugira ngo itangire gukora:
   - npm install
   - npm run build
   - NODE_ENV=production npm start
4. Shiramo Environment Variables (optional, cyangwa uzishyiremo muri Admin Panel):
   - ADMIN_PASSCODE=admin2026
   - PORT=3000
   - CF_ACCOUNT_ID, CF_D1_DATABASE_ID, CF_API_TOKEN (Cloudflare D1)
   - CF_R2_BUCKET, CF_R2_ACCESS_KEY_ID, CF_R2_SECRET_ACCESS_KEY, CF_R2_PUBLIC_URL (Cloudflare R2)
