# AgasobanuyeFree - Amabwiriza yo Guhostinga kuri Render

1. Shyira aya madosiye yose ku mizi ya GitHub repository yawe (kugira ngo package.json na server.ts bibe biri hejuru, bitari muri subfolder).
2. Kuri Render.com -> New Web Service:
   - Build Command: npm install && npm run build
   - Start Command: npm start
   - Environment Variables:
     - NODE_ENV = production
     - NODE_VERSION = 22.22.0
     - ADMIN_PASSCODE = admin2026
